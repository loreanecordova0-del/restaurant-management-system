"""
Setup Sample Data for Kwan's Restaurant Management System
This script creates sample menu items, customers (including PWD/Senior), and initial data
"""
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'pizza.settings')
django.setup()

from django.contrib.auth.models import User
from orders.models import (
    RegularPizza, SicilianPizza, Toppings, Sub, Pasta, Salad, DinnerPlatters,
    Category, MenuItem, Customer, Employee, RestaurantSettings
)
from decimal import Decimal

print("🍕 Setting up Kwan's Restaurant Sample Data...")
print("=" * 50)

# 1. Create Restaurant Settings
print("\n1️⃣ Creating Restaurant Settings...")
settings, created = RestaurantSettings.objects.get_or_create(
    id=1,
    defaults={
        'restaurant_name': "Kwan's Restaurant",
        'address': '123 Main Street, City, Philippines',
        'phone': '+63 912 345 6789',
        'email': 'info@kwansrestaurant.com',
        'tax_rate': Decimal('12.00'),
        'pwd_discount': Decimal('20.00'),
        'senior_discount': Decimal('20.00'),
    }
)
print(f"✅ Restaurant Settings: {settings.restaurant_name}")

# 2. Create Regular Pizzas
print("\n2️⃣ Creating Regular Pizzas...")
regular_pizzas = [
    ('Cheese', 9.50, 17.95),
    ('Pepperoni', 10.50, 19.95),
    ('Hawaiian', 11.00, 20.95),
    ('Meat Lovers', 12.50, 22.95),
    ('Veggie Supreme', 11.50, 21.95),
    ('BBQ Chicken', 12.00, 21.95),
]

for name, small, large in regular_pizzas:
    pizza, created = RegularPizza.objects.get_or_create(
        pizza_choice=name,
        defaults={'small_price': Decimal(str(small)), 'large_price': Decimal(str(large))}
    )
    if created:
        print(f"   ✅ {name} - Small: ${small}, Large: ${large}")

# 3. Create Sicilian Pizzas
print("\n3️⃣ Creating Sicilian Pizzas...")
sicilian_pizzas = [
    ('Sicilian Cheese', 11.50, 19.95),
    ('Sicilian Pepperoni', 12.50, 21.95),
    ('Sicilian Special', 13.50, 23.95),
]

for name, small, large in sicilian_pizzas:
    pizza, created = SicilianPizza.objects.get_or_create(
        pizza_choice=name,
        defaults={'small_price': Decimal(str(small)), 'large_price': Decimal(str(large))}
    )
    if created:
        print(f"   ✅ {name} - Small: ${small}, Large: ${large}")

# 4. Create Toppings
print("\n4️⃣ Creating Toppings...")
toppings_list = [
    ('Extra Cheese', 0.50),
    ('Mushrooms', 0.50),
    ('Onions', 0.50),
    ('Peppers', 0.50),
    ('Olives', 0.50),
    ('Bacon', 0.75),
    ('Sausage', 0.75),
]

for name, price in toppings_list:
    topping, created = Toppings.objects.get_or_create(
        topping_name=name,
        defaults={}
    )
    if created:
        print(f"   ✅ {name}")

# 5. Create Subs
print("\n5️⃣ Creating Subs...")
subs = [
    ('Italian Sub', 6.50, 9.95),
    ('Meatball Sub', 6.95, 10.50),
    ('Chicken Parmesan', 7.50, 11.50),
    ('Steak & Cheese', 7.95, 11.95),
    ('Veggie Sub', 5.95, 8.95),
]

for name, small, large in subs:
    sub, created = Sub.objects.get_or_create(
        sub_filling=name,
        defaults={'small_price': Decimal(str(small)), 'large_price': Decimal(str(large))}
    )
    if created:
        print(f"   ✅ {name} - Small: ${small}, Large: ${large}")

# 6. Create Pasta
print("\n6️⃣ Creating Pasta Dishes...")
pastas = [
    ('Spaghetti with Meatballs', 12.95),
    ('Fettuccine Alfredo', 13.50),
    ('Penne Arrabbiata', 11.95),
    ('Lasagna', 14.50),
    ('Carbonara', 13.95),
]

for name, price in pastas:
    pasta, created = Pasta.objects.get_or_create(
        dish_name=name,
        defaults={'price': Decimal(str(price))}
    )
    if created:
        print(f"   ✅ {name} - ${price}")

# 7. Create Salads
print("\n7️⃣ Creating Salads...")
salads = [
    ('Caesar Salad', 7.95),
    ('Greek Salad', 8.50),
    ('Garden Salad', 6.95),
    ('Caprese Salad', 9.50),
]

for name, price in salads:
    salad, created = Salad.objects.get_or_create(
        dish_name=name,
        defaults={'price': Decimal(str(price))}
    )
    if created:
        print(f"   ✅ {name} - ${price}")

# 8. Create Dinner Platters
print("\n8️⃣ Creating Dinner Platters...")
platters = [
    ('Chicken Platter', 15.95, 24.95),
    ('Beef Platter', 17.95, 27.95),
    ('Seafood Platter', 18.95, 29.95),
    ('Mixed Grill Platter', 19.95, 31.95),
]

for name, small, large in platters:
    platter, created = DinnerPlatters.objects.get_or_create(
        dish_name=name,
        defaults={'small_price': Decimal(str(small)), 'large_price': Decimal(str(large))}
    )
    if created:
        print(f"   ✅ {name} - Small: ${small}, Large: ${large}")

# 9. Create Sample Customers (INCLUDING PWD AND SENIOR FOR DISCOUNT TESTING)
print("\n9️⃣ Creating Sample Customers...")

sample_customers = [
    {
        'first_name': 'John',
        'last_name': 'Doe',
        'phone': '0912-345-6789',
        'email': 'john.doe@email.com',
        'customer_type': 'regular',
        'id_number': '',
    },
    {
        'first_name': 'Maria',
        'last_name': 'Santos',
        'phone': '0923-456-7890',
        'email': 'maria.santos@email.com',
        'customer_type': 'pwd',
        'id_number': 'PWD-2024-001',
    },
    {
        'first_name': 'Pedro',
        'last_name': 'Reyes',
        'phone': '0934-567-8901',
        'email': 'pedro.reyes@email.com',
        'customer_type': 'senior',
        'id_number': 'SC-2024-001',
    },
    {
        'first_name': 'Ana',
        'last_name': 'Cruz',
        'phone': '0945-678-9012',
        'email': 'ana.cruz@email.com',
        'customer_type': 'regular',
        'id_number': '',
    },
]

for customer_data in sample_customers:
    customer, created = Customer.objects.get_or_create(
        phone=customer_data['phone'],
        defaults=customer_data
    )
    if created:
        discount_info = ""
        if customer.customer_type == 'pwd':
            discount_info = f" (PWD - 20% discount, ID: {customer.id_number})"
        elif customer.customer_type == 'senior':
            discount_info = f" (Senior Citizen - 20% discount, ID: {customer.id_number})"
        print(f"   ✅ {customer.first_name} {customer.last_name}{discount_info}")

# 10. Create Categories
print("\n🔟 Creating Menu Categories...")
categories = [
    ('Pizza', 'Delicious handcrafted pizzas', 1),
    ('Pasta', 'Fresh Italian pasta dishes', 2),
    ('Subs', 'Hearty submarine sandwiches', 3),
    ('Salads', 'Fresh and healthy salads', 4),
    ('Platters', 'Complete dinner platters', 5),
]

for title, desc, order in categories:
    category, created = Category.objects.get_or_create(
        category_title=title,
        defaults={
            'category_description': desc,
            'display_order': order,
            'is_active': True
        }
    )
    if created:
        print(f"   ✅ {title}")

print("\n" + "=" * 50)
print("✅ SAMPLE DATA SETUP COMPLETE!")
print("=" * 50)

print("\n📊 Summary:")
print(f"   • Regular Pizzas: {RegularPizza.objects.count()}")
print(f"   • Sicilian Pizzas: {SicilianPizza.objects.count()}")
print(f"   • Toppings: {Toppings.objects.count()}")
print(f"   • Subs: {Sub.objects.count()}")
print(f"   • Pasta: {Pasta.objects.count()}")
print(f"   • Salads: {Salad.objects.count()}")
print(f"   • Platters: {DinnerPlatters.objects.count()}")
print(f"   • Customers: {Customer.objects.count()}")
print(f"   • PWD Customers: {Customer.objects.filter(customer_type='pwd').count()}")
print(f"   • Senior Customers: {Customer.objects.filter(customer_type='senior').count()}")

print("\n🎯 Test Customers for Discounts:")
print("   PWD Customer: Maria Santos (PWD-2024-001) - Gets 20% discount")
print("   Senior Customer: Pedro Reyes (SC-2024-001) - Gets 20% discount")

print("\n🚀 You can now:")
print("   1. View menu at: http://127.0.0.1:8000/menu/")
print("   2. Login and create orders with discounts")
print("   3. Test all features")
print("\n✨ System is ready for demonstration!")
