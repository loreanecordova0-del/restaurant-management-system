# 🍕 HOW TO USE KWAN'S RESTAURANT MANAGEMENT SYSTEM

## Complete Guide to Demonstrate All Features

---

## 🚀 QUICK START

### 1. Start the Server
```bash
cd C:\Users\Admin\Desktop\kwan's resto_ordering system
python manage.py runserver
```

Server will run at: **http://127.0.0.1:8000/**

### 2. Login Credentials
- **Username**: `admin` or `admin28`
- **Password**: `admin123`

---

## 📋 ALL FEATURES & HOW TO USE THEM

### ✅ FEATURE 1: Digital Point of Sale (POS) System

**Purpose**: Record customer orders accurately (Solves Problem #1)

**How to Access**:
1. Login at: http://127.0.0.1:8000/login/
2. Click "POS" in navigation OR go to: http://127.0.0.1:8000/pos/

**How to Create an Order with Discount**:

#### A. Regular Customer Order (No Discount):
1. Go to POS interface
2. Select customer: **John Doe** (Regular)
3. Add items from menu:
   - Example: Pepperoni Pizza (Large) - $19.95
   - Example: Caesar Salad - $7.95
4. Enter table number (e.g., Table 5)
5. Select payment method: Cash
6. Click "Create Order"
7. **Total**: $27.90 + 12% tax = $31.25

#### B. PWD Customer Order (20% Discount):
1. Go to POS interface
2. Select customer: **Maria Santos (PWD)**
3. Customer ID: **PWD-2024-001**
4. Add items:
   - Hawaiian Pizza (Large) - $20.95
   - Greek Salad - $8.50
5. System automatically applies **20% PWD discount**
6. **Calculation**:
   - Subtotal: $29.45
   - PWD Discount (20%): -$5.89
   - After discount: $23.56
   - Tax (12%): +$2.83
   - **Final Total**: $26.39

#### C. Senior Citizen Order (20% Discount):
1. Go to POS interface
2. Select customer: **Pedro Reyes (Senior)**
3. Customer ID: **SC-2024-001**
4. Add items:
   - Spaghetti with Meatballs - $12.95
   - Steak & Cheese Sub (Large) - $11.95
5. System automatically applies **20% Senior discount**
6. **Calculation**:
   - Subtotal: $24.90
   - Senior Discount (20%): -$4.98
   - After discount: $19.92
   - Tax (12%): +$2.39
   - **Final Total**: $22.31

---

### ✅ FEATURE 2: Sales Tracking & Analytics

**Purpose**: Track sales with real-time monitoring (Solves Problem #2)

**How to Access**:
http://127.0.0.1:8000/sales/dashboard/

**What You'll See**:
- Today's Revenue
- Total Orders
- Sales Charts
- Best-selling Items
- Hourly Sales Breakdown

**Generate Daily Report**:
1. Go to: http://127.0.0.1:8000/sales/daily-report/
2. Select date
3. Click "Generate PDF Report"
4. Download PDF with complete sales summary

**Export Sales Data**:
1. Go to: http://127.0.0.1:8000/sales/export/
2. Select date range
3. Click "Export to Excel"
4. Download Excel file with all transactions

---

### ✅ FEATURE 3: Customer Relationship Management (CRM)

**Purpose**: Handle customer complaints & feedback (Solves Problem #3)

**Access**: http://127.0.0.1:8000/customers/

**How to Add New Customer**:
1. Click "Add Customer"
2. Fill in details:
   - Name: Jane Smith
   - Phone: 0912-111-2222
   - Customer Type: Regular
3. Click "Save"

**How to Add PWD Customer**:
1. Click "Add Customer"
2. Fill in details:
   - Name: Carlos Garcia
   - Phone: 0923-222-3333
   - Customer Type: **PWD**
   - ID Number: **PWD-2024-002** (Required!)
3. System validates and confirms 20% discount eligibility

**How to Handle Customer Complaint**:
1. Go to: http://127.0.0.1:8000/feedback/
2. Click "Add Feedback"
3. Select customer and order
4. Rate service (1-5 stars):
   - Food Quality: 2 stars (Low rating = Complaint)
   - Service: 2 stars
   - Ambiance: 3 stars
5. Comments: "Food was cold, service slow"
6. Click "Submit"
7. System automatically flags as **CRITICAL COMPLAINT**
8. Redirects to resolution form
9. Manager enters:
   - Resolution: "Refunded order, offered complimentary meal"
   - Action taken: "Retrained kitchen staff on timing"
10. Mark as "Resolved"
11. Customer satisfaction tracked

---

### ✅ FEATURE 4: Employee Management & QR Time Tracking

**Access**: http://127.0.0.1:8000/employee/management/

**Add Employee**:
1. Click "Add Employee"
2. Fill details:
   - Name: Juan Dela Cruz
   - Employee ID: EMP-001
   - Role: Cashier
   - Hourly Rate: 75.00
3. System generates QR code for time tracking

**Employee Time Clock (QR-based)**:
1. Go to: http://127.0.0.1:8000/employee/time-clock/
2. Employee scans their QR code
3. System records:
   - Clock In time
   - Clock Out time
   - Break start/end
   - Total hours worked
4. Automatic overtime calculation

**View Time Reports**:
1. Go to: http://127.0.0.1:8000/employee/time-report/
2. Select employee and date range
3. View total hours, overtime, breaks
4. Export to PDF or Excel

---

### ✅ FEATURE 5: Kitchen Display System

**Purpose**: Faster order preparation and service

**Access**: http://127.0.0.1:8000/kitchen/display/

**How It Works**:
1. When order is created in POS, it immediately appears on Kitchen Display
2. Kitchen staff see:
   - Order number
   - Table number
   - Items to prepare
   - Special instructions
   - Time elapsed
3. Kitchen staff update status:
   - **Pending** → **Preparing** → **Ready** → **Served**
4. Color coding:
   - Green: New orders
   - Yellow: In preparation
   - Red: Taking too long
5. Expeditor view shows all orders in sequence

---

### ✅ FEATURE 6: Menu Management

**Access**: http://127.0.0.1:8000/menu/management/

**Current Menu Items** (Pre-loaded):

**Regular Pizzas**:
- Cheese (Small: $9.50, Large: $17.95)
- Pepperoni (Small: $10.50, Large: $19.95)
- Hawaiian (Small: $11.00, Large: $20.95)
- Meat Lovers (Small: $12.50, Large: $22.95)
- Veggie Supreme (Small: $11.50, Large: $21.95)
- BBQ Chicken (Small: $12.00, Large: $21.95)

**Sicilian Pizzas**:
- Sicilian Cheese (Small: $11.50, Large: $19.95)
- Sicilian Pepperoni (Small: $12.50, Large: $21.95)
- Sicilian Special (Small: $13.50, Large: $23.95)

**Subs**:
- Italian Sub (Small: $6.50, Large: $9.95)
- Meatball Sub (Small: $6.95, Large: $10.50)
- Chicken Parmesan (Small: $7.50, Large: $11.50)
- Steak & Cheese (Small: $7.95, Large: $11.95)
- Veggie Sub (Small: $5.95, Large: $8.95)

**Pasta**:
- Spaghetti with Meatballs ($12.95)
- Fettuccine Alfredo ($13.50)
- Penne Arrabbiata ($11.95)
- Lasagna ($14.50)
- Carbonara ($13.95)

**Salads**:
- Caesar Salad ($7.95)
- Greek Salad ($8.50)
- Garden Salad ($6.95)
- Caprese Salad ($9.50)

**Dinner Platters**:
- Chicken Platter (Small: $15.95, Large: $24.95)
- Beef Platter (Small: $17.95, Large: $27.95)
- Seafood Platter (Small: $18.95, Large: $29.95)
- Mixed Grill Platter (Small: $19.95, Large: $31.95)

**How to Update Menu**:
1. Click item to edit
2. Change price or description
3. Toggle availability on/off
4. Save changes

---

### ✅ FEATURE 7: Reporting & Analytics

**Access**: http://127.0.0.1:8000/reports/

**Available Reports**:
1. **Daily Sales Report**
   - Total revenue
   - Number of orders
   - Average order value
   - Best-selling items
   
2. **Employee Time Report**
   - Hours worked by employee
   - Overtime calculation
   - Attendance records
   
3. **Customer Analytics**
   - Frequent customers
   - Customer lifetime value
   - Discount usage statistics
   
4. **Kitchen Performance**
   - Average preparation time
   - Order accuracy rate
   - Peak hours analysis
   
5. **Menu Analytics**
   - Most popular items
   - Slow-moving items
   - Revenue by category

---

## 🎯 DEMONSTRATION SCENARIOS

### Scenario 1: Regular Customer Order
1. Create order for **John Doe**
2. Add Pepperoni Pizza + Salad
3. Total with tax: ~$31
4. Process payment
5. Order appears in Kitchen Display
6. Kitchen marks as preparing → ready → served

### Scenario 2: PWD Customer with Discount
1. Create order for **Maria Santos (PWD-2024-001)**
2. Add Hawaiian Pizza + Greek Salad
3. System shows 20% discount applied
4. Original: $29.45 → After discount: $23.56
5. Add 12% tax → Final: $26.39
6. Generate receipt showing discount

### Scenario 3: Handling Complaint
1. Customer gives low rating (2 stars)
2. System flags as critical
3. Manager reviews complaint
4. Enters resolution details
5. Marks as resolved
6. Tracks in CRM for follow-up

### Scenario 4: Sales Reporting
1. End of day: Generate daily report
2. Shows:
   - Total sales: $X,XXX.XX
   - Number of orders: XX
   - PWD discounts given: $XXX.XX
   - Senior discounts given: $XXX.XX
3. Export to PDF
4. Send to owner/manager

---

## 📊 SYSTEM SETTINGS

**Access**: http://127.0.0.1:8000/settings/

**Current Settings**:
- Restaurant Name: Kwan's Restaurant
- Tax Rate: 12%
- PWD Discount: 20%
- Senior Discount: 20%

**To Change Settings**:
1. Login as admin
2. Go to Settings
3. Update values
4. Save changes

---

## 🎓 ADMIN PANEL

**Access**: http://127.0.0.1:8000/admin/

**You can manage**:
- All menu items
- All customers
- All orders
- All employees
- System settings

---

## ✅ TESTING CHECKLIST

- [ ] View full menu with all prices
- [ ] Create order for regular customer
- [ ] Create order with PWD discount
- [ ] Create order with Senior discount
- [ ] View order in Kitchen Display
- [ ] Update order status
- [ ] Add customer feedback/complaint
- [ ] Resolve complaint
- [ ] Clock in/out employee
- [ ] Generate daily sales report
- [ ] Export sales to Excel
- [ ] View sales analytics dashboard
- [ ] Update menu item price
- [ ] View customer list with discount eligibility

---

## 📱 QUICK ACCESS LINKS

- **Home**: http://127.0.0.1:8000/
- **Menu**: http://127.0.0.1:8000/menu/
- **POS**: http://127.0.0.1:8000/pos/
- **Dashboard**: http://127.0.0.1:8000/dashboard/
- **Customers**: http://127.0.0.1:8000/customers/
- **Sales**: http://127.0.0.1:8000/sales/dashboard/
- **Kitchen**: http://127.0.0.1:8000/kitchen/display/
- **Reports**: http://127.0.0.1:8000/reports/
- **Admin**: http://127.0.0.1:8000/admin/

---

## 🎉 YOUR SYSTEM IS READY!

Everything is set up with sample data. You can now demonstrate:
✅ Accurate order recording (Problem #1 SOLVED)
✅ Real-time sales tracking (Problem #2 SOLVED)
✅ Customer complaint handling (Problem #3 SOLVED)
✅ PWD & Senior discounts working
✅ All features functional
✅ Complete restaurant management

**The system addresses ALL objectives from your proposal!**
