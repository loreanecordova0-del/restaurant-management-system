import { useNavigate } from 'react-router-dom';

function MenuItem({ item, addToCart }) {
    const navigate = useNavigate();

    function handleAdd() {
        addToCart(item);
        navigate('/yourcart');
    }

    return (
        <>
            <h3>{item.name}</h3>
            <p>{item.description}</p>
            <button onClick={handleAdd}>Add to cart</button>
        </>
    );
}

export default MenuItem;