# Customer Management Views - Solving Problem #3: Difficulties in handling customer complaints
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.db.models import Sum, Count, Avg, Q
from django.utils import timezone
from django.core.paginator import Paginator
from datetime import date, timedelta
import json

from .models import Customer, CustomerFeedback, Order, Employee

@login_required
def customer_management(request):
    """Customer management interface with complaint tracking"""
    customers = Customer.objects.all().order_by('-created_at')
    
    # Filter options
    customer_type = request.GET.get('type')
    if customer_type:
        customers = customers.filter(customer_type=customer_type)
    
    # Search
    search_query = request.GET.get('search')
    if search_query:
        customers = customers.filter(
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query) |
            Q(phone__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(id_number__icontains=search_query)
        )
    
    # Get statistics
    total_customers = Customer.objects.count()
    pwd_count = Customer.objects.filter(customer_type='pwd').count()
    senior_count = Customer.objects.filter(customer_type='senior').count()
    regular_count = Customer.objects.filter(customer_type='regular').count()
    
    # Recent complaints
    recent_complaints = CustomerFeedback.objects.filter(
        resolved=False
    ).order_by('-created_at')[:5]
    
    # Top customers by spending
    top_customers = Customer.objects.filter(
        total_spent__gt=0
    ).order_by('-total_spent')[:5]
    
    # Recent customers
    recent_customers = Customer.objects.order_by('-created_at')[:5]
    
    paginator = Paginator(customers, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'customers': page_obj,
        'total_customers': total_customers,
        'pwd_count': pwd_count,
        'senior_count': senior_count,
        'regular_count': regular_count,
        'recent_complaints': recent_complaints,
        'unresolved_complaints': CustomerFeedback.objects.filter(resolved=False).count(),
        'top_customers': top_customers,
        'recent_customers': recent_customers,
    }
    return render(request, 'orders/customer_management.html', context)

@login_required
def add_customer(request):
    """Add new customer with discount eligibility"""
    if request.method == 'POST':
        # Validate PWD/Senior ID if applicable
        customer_type = request.POST.get('customer_type', 'regular')
        id_number = request.POST.get('id_number', '')
        
        if customer_type in ['pwd', 'senior'] and not id_number:
            messages.error(request, f'{customer_type.upper()} ID number is required for discount eligibility!')
            return redirect('orders:add_customer')
        
        # Check for duplicate ID number
        if id_number and Customer.objects.filter(id_number=id_number).exists():
            messages.error(request, 'This ID number is already registered!')
            return redirect('orders:add_customer')
        
        customer = Customer.objects.create(
            first_name=request.POST.get('first_name'),
            last_name=request.POST.get('last_name'),
            email=request.POST.get('email') or None,
            phone=request.POST.get('phone'),
            customer_type=customer_type,
            id_number=id_number,
            date_of_birth=request.POST.get('date_of_birth') or None,
            notes=request.POST.get('notes', '')
        )
        
        # Show discount eligibility message
        if customer_type in ['pwd', 'senior']:
            discount_rate = customer.get_discount_percentage()
            messages.success(request, f'Customer added! Eligible for {discount_rate}% discount.')
        else:
            messages.success(request, 'Customer added successfully!')
        
        return redirect('orders:customer_detail', customer_id=customer.id)
    
    return render(request, 'orders/add_customer.html')

@login_required
def customer_detail(request, customer_id):
    """Customer detail view with order history and feedback"""
    customer = get_object_or_404(Customer, id=customer_id)
    
    # Get order history
    orders = Order.objects.filter(customer=customer).order_by('-order_date')
    
    # Get feedback/complaints
    feedbacks = CustomerFeedback.objects.filter(customer=customer).order_by('-created_at')
    
    # Calculate statistics
    total_spent = orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    total_orders = orders.count()
    total_discounts = orders.aggregate(Sum('discount_amount'))['discount_amount__sum'] or 0
    
    # Average ratings from feedback
    avg_ratings = feedbacks.aggregate(
        avg_food=Avg('food_rating'),
        avg_service=Avg('service_rating'),
        avg_ambiance=Avg('ambiance_rating')
    )
    
    # Favorite items (most ordered)
    favorite_items = []
    if orders.exists():
        from .models import OrderItem
        favorite_items = OrderItem.objects.filter(
            order__customer=customer
        ).values('menu_item__name').annotate(
            count=Count('id'),
            total=Sum('quantity')
        ).order_by('-total')[:5]
    
    context = {
        'customer': customer,
        'orders': orders[:10],  # Recent 10 orders
        'feedbacks': feedbacks,
        'total_spent': total_spent,
        'total_orders': total_orders,
        'total_discounts': total_discounts,
        'avg_ratings': avg_ratings,
        'favorite_items': favorite_items,
        'discount_percentage': customer.get_discount_percentage()
    }
    return render(request, 'orders/customer_detail.html', context)

@login_required
def edit_customer(request, customer_id):
    """Edit customer information"""
    customer = get_object_or_404(Customer, id=customer_id)
    
    if request.method == 'POST':
        customer.first_name = request.POST.get('first_name')
        customer.last_name = request.POST.get('last_name')
        customer.email = request.POST.get('email') or None
        customer.phone = request.POST.get('phone')
        customer.customer_type = request.POST.get('customer_type')
        customer.id_number = request.POST.get('id_number', '')
        customer.date_of_birth = request.POST.get('date_of_birth') or None
        customer.notes = request.POST.get('notes', '')
        customer.save()
        
        messages.success(request, 'Customer information updated!')
        return redirect('orders:customer_detail', customer_id=customer.id)
    
    return render(request, 'orders/edit_customer.html', {'customer': customer})

@login_required
def feedback_management(request):
    """Customer feedback and complaint management system"""
    feedbacks = CustomerFeedback.objects.all().order_by('-created_at')
    
    # Filters
    status_filter = request.GET.get('status')
    if status_filter == 'unresolved':
        feedbacks = feedbacks.filter(resolved=False)
    elif status_filter == 'resolved':
        feedbacks = feedbacks.filter(resolved=True)
    
    rating_filter = request.GET.get('rating')
    if rating_filter:
        feedbacks = feedbacks.filter(
            Q(food_rating__lte=int(rating_filter)) |
            Q(service_rating__lte=int(rating_filter)) |
            Q(ambiance_rating__lte=int(rating_filter))
        )
    
    # Search
    search_query = request.GET.get('search')
    if search_query:
        feedbacks = feedbacks.filter(
            Q(comments__icontains=search_query) |
            Q(customer__first_name__icontains=search_query) |
            Q(customer__last_name__icontains=search_query)
        )
    
    # Statistics
    total_feedback = CustomerFeedback.objects.count()
    unresolved_count = CustomerFeedback.objects.filter(resolved=False).count()
    resolved_today = CustomerFeedback.objects.filter(
        resolved=True,
        resolved_at__date=date.today()
    ).count()
    
    # Average ratings
    avg_ratings = CustomerFeedback.objects.aggregate(
        avg_food=Avg('food_rating'),
        avg_service=Avg('service_rating'),
        avg_ambiance=Avg('ambiance_rating')
    )
    
    # Critical complaints (rating <= 2)
    critical_complaints = feedbacks.filter(
        Q(food_rating__lte=2) | Q(service_rating__lte=2) | Q(ambiance_rating__lte=2),
        resolved=False
    )
    
    paginator = Paginator(feedbacks, 15)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'feedbacks': page_obj,
        'total_feedback': total_feedback,
        'unresolved_count': unresolved_count,
        'resolved_today': resolved_today,
        'avg_ratings': avg_ratings,
        'critical_complaints': critical_complaints.count(),
        'critical_list': critical_complaints[:5]
    }
    return render(request, 'orders/feedback_management.html', context)

@login_required
def add_feedback(request):
    """Add customer feedback"""
    if request.method == 'POST':
        customer_id = request.POST.get('customer_id')
        order_id = request.POST.get('order_id')
        
        # Get customer and order
        customer = get_object_or_404(Customer, id=customer_id) if customer_id else None
        order = get_object_or_404(Order, id=order_id) if order_id else None
        
        # Create feedback
        feedback = CustomerFeedback.objects.create(
            customer=customer,
            order=order,
            food_rating=int(request.POST.get('food_rating', 3)),
            service_rating=int(request.POST.get('service_rating', 3)),
            ambiance_rating=int(request.POST.get('ambiance_rating', 3)),
            comments=request.POST.get('comments', '')
        )
        
        # Check if it's a complaint (low rating)
        if feedback.food_rating <= 2 or feedback.service_rating <= 2 or feedback.ambiance_rating <= 2:
            messages.warning(request, 'Low rating detected. Please address this complaint promptly.')
            return redirect('orders:resolve_feedback', feedback_id=feedback.id)
        
        messages.success(request, 'Feedback recorded successfully!')
        return redirect('orders:feedback_management')
    
    customers = Customer.objects.all().order_by('first_name')
    recent_orders = Order.objects.filter(
        order_date__gte=timezone.now() - timedelta(days=7)
    ).order_by('-order_date')
    
    return render(request, 'orders/add_feedback.html', {
        'customers': customers,
        'recent_orders': recent_orders
    })

@login_required
def resolve_feedback(request, feedback_id):
    """Resolve customer feedback/complaint"""
    feedback = get_object_or_404(CustomerFeedback, id=feedback_id)
    
    if request.method == 'POST':
        response = request.POST.get('response')
        action_taken = request.POST.get('action_taken', '')
        
        feedback.response = f"{response}\n\nAction taken: {action_taken}"
        feedback.resolved = True
        feedback.resolved_at = timezone.now()
        
        if hasattr(request.user, 'employee_profile'):
            feedback.resolved_by = request.user.employee_profile
        
        feedback.save()
        
        # Send notification to customer if email exists
        if feedback.customer and feedback.customer.email:
            # In a real system, you would send an email here
            pass
        
        messages.success(request, 'Feedback resolved successfully!')
        
        # Check if there are more unresolved complaints
        next_complaint = CustomerFeedback.objects.filter(
            resolved=False
        ).exclude(id=feedback_id).first()
        
        if next_complaint:
            messages.info(request, 'There are more unresolved complaints.')
            return redirect('orders:resolve_feedback', feedback_id=next_complaint.id)
        
        return redirect('orders:feedback_management')
    
    # Get similar past complaints
    similar_complaints = CustomerFeedback.objects.filter(
        resolved=True
    ).exclude(id=feedback_id)
    
    # Filter by similar ratings
    if feedback.food_rating <= 2:
        similar_complaints = similar_complaints.filter(food_rating__lte=2)
    if feedback.service_rating <= 2:
        similar_complaints = similar_complaints.filter(service_rating__lte=2)
    
    similar_complaints = similar_complaints[:3]
    
    context = {
        'feedback': feedback,
        'similar_complaints': similar_complaints
    }
    return render(request, 'orders/resolve_feedback.html', context)

@login_required
@require_POST
def quick_resolve_feedback(request, feedback_id):
    """Quick resolve feedback via AJAX"""
    try:
        feedback = get_object_or_404(CustomerFeedback, id=feedback_id)
        response = request.POST.get('response')
        
        feedback.response = response
        feedback.resolved = True
        feedback.resolved_at = timezone.now()
        
        if hasattr(request.user, 'employee_profile'):
            feedback.resolved_by = request.user.employee_profile
        
        feedback.save()
        
        return JsonResponse({
            'success': True,
            'message': 'Feedback resolved successfully!'
        })
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=400)

@login_required
def customer_loyalty(request):
    """Customer loyalty program management"""
    # Top customers by spending
    top_customers = Customer.objects.annotate(
        order_count=Count('order')
    ).filter(order_count__gt=0).order_by('-total_spent')[:10]
    
    # Loyalty tiers based on points
    loyalty_tiers = [
        {'name': 'Bronze', 'min_points': 0, 'max_points': 499, 'benefits': '5% discount on next order'},
        {'name': 'Silver', 'min_points': 500, 'max_points': 999, 'benefits': '10% discount + Free dessert'},
        {'name': 'Gold', 'min_points': 1000, 'max_points': 2499, 'benefits': '15% discount + Priority seating'},
        {'name': 'Platinum', 'min_points': 2500, 'max_points': None, 'benefits': '20% discount + VIP treatment'}
    ]
    
    # Group customers by tier
    tier_distribution = {
        'Bronze': Customer.objects.filter(loyalty_points__lt=500).count(),
        'Silver': Customer.objects.filter(loyalty_points__gte=500, loyalty_points__lt=1000).count(),
        'Gold': Customer.objects.filter(loyalty_points__gte=1000, loyalty_points__lt=2500).count(),
        'Platinum': Customer.objects.filter(loyalty_points__gte=2500).count()
    }
    
    context = {
        'top_customers': top_customers,
        'loyalty_tiers': loyalty_tiers,
        'tier_distribution': tier_distribution,
        'total_members': Customer.objects.exclude(loyalty_points=0).count()
    }
    return render(request, 'orders/customer_loyalty.html', context)

@login_required
def customer_analytics(request):
    """Customer analytics dashboard"""
    # Date range
    end_date = date.today()
    start_date = end_date - timedelta(days=30)
    
    # Customer acquisition (new customers per day)
    new_customers_data = []
    current_date = start_date
    while current_date <= end_date:
        count = Customer.objects.filter(created_at__date=current_date).count()
        new_customers_data.append({
            'date': current_date.strftime('%Y-%m-%d'),
            'count': count
        })
        current_date += timedelta(days=1)
    
    # Customer type distribution
    type_distribution = Customer.objects.values('customer_type').annotate(
        count=Count('id')
    )
    
    # Repeat customers (more than 1 order)
    repeat_customers = Customer.objects.annotate(
        order_count=Count('order')
    ).filter(order_count__gt=1).count()
    
    total_customers = Customer.objects.count()
    repeat_rate = (repeat_customers / total_customers * 100) if total_customers > 0 else 0
    
    # Average customer lifetime value
    avg_lifetime_value = Customer.objects.aggregate(
        avg_value=Avg('total_spent')
    )['avg_value'] or 0
    
    # Customer satisfaction (from feedback)
    avg_satisfaction = CustomerFeedback.objects.aggregate(
        food=Avg('food_rating'),
        service=Avg('service_rating'),
        ambiance=Avg('ambiance_rating')
    )
    
    context = {
        'new_customers_data': new_customers_data,
        'type_distribution': list(type_distribution),
        'repeat_rate': repeat_rate,
        'repeat_customers': repeat_customers,
        'total_customers': total_customers,
        'avg_lifetime_value': avg_lifetime_value,
        'avg_satisfaction': avg_satisfaction
    }
    
    return render(request, 'orders/customer_analytics.html', context)

@login_required
@require_POST
def add_loyalty_points(request, customer_id):
    """Manually add loyalty points to customer"""
    customer = get_object_or_404(Customer, id=customer_id)
    points = int(request.POST.get('points', 0))
    reason = request.POST.get('reason', '')
    
    if points > 0:
        customer.loyalty_points += points
        customer.notes += f"\n{timezone.now().strftime('%Y-%m-%d')}: Added {points} points - {reason}"
        customer.save()
        
        return JsonResponse({
            'success': True,
            'new_total': customer.loyalty_points
        })
    
    return JsonResponse({'success': False, 'error': 'Invalid points value'}, status=400)
