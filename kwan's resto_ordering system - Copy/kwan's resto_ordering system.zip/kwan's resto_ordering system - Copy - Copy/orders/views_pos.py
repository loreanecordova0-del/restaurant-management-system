# POS System Views - Solving Problem #1: Errors in recording orders
from django.shortcuts import render, redirect, get_object_or_404
from .views_pos_simple import create_simple_order
from django.contrib.auth.decorators import login_required, user_passes_test
from django.http import JsonResponse, HttpResponse
from django.views.decorators.http import require_POST
from django.utils import timezone
from django.db.models import Sum, Q
from decimal import Decimal
import json
import random
import string
from datetime import date
import io
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch

from .models import (
    Category, MenuItem, Order, OrderItem, Customer,
    Employee, DailySales, KitchenOrder, RestaurantSettings
)

def is_staff(user):
    """Check if user is staff member"""
    if hasattr(user, 'employee_profile'):
        return user.employee_profile.is_active
    return False

def generate_order_number():
    """Generate unique order number"""
    timestamp = timezone.now().strftime('%Y%m%d%H%M')
    random_suffix = ''.join(random.choices(string.digits, k=4))
    return f"ORD-{timestamp}-{random_suffix}"

@login_required
def pos_interface(request):
    """Main POS interface for accurate order recording"""
    from .models import RegularPizza, SicilianPizza, Sub, Pasta, Salad, DinnerPlatters
    
    # Get all menu items
    regular_pizzas = RegularPizza.objects.all()
    sicilian_pizzas = SicilianPizza.objects.all()
    # Combine pizzas
    pizzas = list(regular_pizzas) + list(sicilian_pizzas)
    
    customers = Customer.objects.all().order_by('first_name')
    tables = range(1, 21)  # 20 tables
    
    # Get restaurant settings for tax and discount rates
    settings = RestaurantSettings.objects.first()
    if not settings:
        settings = RestaurantSettings.objects.create(
            restaurant_name="Kwan's Restaurant",
            address="123 Restaurant Street, City",
            phone="(02) 1234-5678",
            email="info@kwansrestaurant.com",
            tax_rate=12,
            pwd_discount=20,
            senior_discount=20
        )
    
    context = {
        'pizzas': pizzas,
        'subs': Sub.objects.all(),
        'pastas': Pasta.objects.all(),
        'salads': Salad.objects.all(),
        'platters': DinnerPlatters.objects.all(),
        'customers': customers,
        'tables': tables,
        'tax_rate': settings.tax_rate,
        'pwd_discount': settings.pwd_discount,
        'senior_discount': settings.senior_discount,
    }
    return render(request, 'orders/pos_interface.html', context)

@login_required
@require_POST
def create_order(request):
    """Create new order with accurate recording and discount application"""
    try:
        data = json.loads(request.body)
        
        # Get customer and check discount eligibility
        customer = None
        discount_amount = Decimal('0')
        discount_type = ''
        
        if data.get('customer_id'):
            customer = Customer.objects.get(id=data['customer_id'])
            
            # Apply PWD/Senior discount automatically
            if customer.customer_type in ['pwd', 'senior']:
                subtotal = Decimal(data.get('subtotal', 0))
                discount_percentage = customer.get_discount_percentage()
                discount_amount = (subtotal * Decimal(discount_percentage)) / 100
                discount_type = f"{customer.customer_type.upper()} Discount ({discount_percentage}%)"
        
        # Create order
        order = Order.objects.create(
            order_number=generate_order_number(),
            customer=customer,
            table_number=data.get('table_number'),
            payment_method=data.get('payment_method', 'cash'),
            discount_type=discount_type,
            discount_amount=discount_amount,
            notes=data.get('notes', ''),
            cashier=request.user.employee_profile if hasattr(request.user, 'employee_profile') else None,
            status='confirmed'
        )
        
        # Add order items with accurate recording
        for item_data in data.get('items', []):
            menu_item = MenuItem.objects.get(id=item_data['menu_item_id'])
            
            # Determine price based on size
            price = Decimal(item_data.get('price', menu_item.base_price))
            size = item_data.get('size', 'regular')
            
            if size in menu_item.sizes_available:
                price = Decimal(str(menu_item.sizes_available[size]))
            
            OrderItem.objects.create(
                order=order,
                menu_item=menu_item,
                quantity=item_data['quantity'],
                size=size,
                price=price,
                special_instructions=item_data.get('special_instructions', '')
            )
        
        # Calculate totals accurately
        order.calculate_totals()
        
        # Send to kitchen display
        send_to_kitchen(order)
        
        # Update customer stats
        if order.customer:
            order.customer.visit_count += 1
            order.customer.total_spent += order.total_amount
            order.customer.last_visit = timezone.now()
            # Add loyalty points (1 point per 100 pesos spent)
            order.customer.loyalty_points += int(order.total_amount / 100)
            order.customer.save()
        
        # Update daily sales immediately for real-time tracking
        update_daily_sales(order)
        
        return JsonResponse({
            'success': True,
            'order_number': order.order_number,
            'order_id': order.id,
            'total_amount': float(order.total_amount),
            'discount_applied': float(discount_amount)
        })
        
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=400)

def send_to_kitchen(order):
    """Send order to kitchen display system"""
    # Group items by station
    stations = {
        'Hot Kitchen': [],
        'Cold Kitchen': [],
        'Drinks': [],
        'Desserts': []
    }
    
    for item in order.items.all():
        # Determine station based on category
        category = item.menu_item.category.category_title.lower()
        
        item_data = {
            'item': item.menu_item.name,
            'quantity': item.quantity,
            'size': item.size,
            'instructions': item.special_instructions,
            'table': order.table_number
        }
        
        if any(word in category for word in ['pizza', 'pasta', 'rice', 'meat', 'soup', 'main', 'platter']):
            stations['Hot Kitchen'].append(item_data)
        elif any(word in category for word in ['salad', 'appetizer', 'cold']):
            stations['Cold Kitchen'].append(item_data)
        elif any(word in category for word in ['drink', 'beverage', 'juice', 'coffee', 'tea']):
            stations['Drinks'].append(item_data)
        elif any(word in category for word in ['dessert', 'sweet', 'ice cream']):
            stations['Desserts'].append(item_data)
        else:
            # Default to hot kitchen
            stations['Hot Kitchen'].append(item_data)
    
    # Create kitchen orders for each station
    for station, items in stations.items():
        if items:
            KitchenOrder.objects.create(
                order=order,
                station=station,
                items=items,
                status='pending'
            )

def update_daily_sales(order):
    """Update daily sales for real-time tracking"""
    today = date.today()
    daily_sales, created = DailySales.objects.get_or_create(date=today)
    
    daily_sales.total_orders += 1
    daily_sales.total_revenue += order.total_amount
    daily_sales.total_discount += order.discount_amount
    daily_sales.total_tax += order.tax_amount
    
    # Update payment method totals
    if order.payment_method == 'cash':
        daily_sales.cash_sales += order.total_amount
    elif order.payment_method == 'card':
        daily_sales.card_sales += order.total_amount
    else:  # gcash, maya
        daily_sales.digital_sales += order.total_amount
    
    daily_sales.save()

@login_required
def search_menu_items(request):
    """Search menu items for POS"""
    query = request.GET.get('q', '')
    if query:
        items = MenuItem.objects.filter(
            Q(name__icontains=query) |
            Q(description__icontains=query) |
            Q(category__category_title__icontains=query),
            is_available=True
        ).values('id', 'name', 'base_price', 'category__category_title', 'sizes_available')[:10]
        return JsonResponse(list(items), safe=False)
    return JsonResponse([], safe=False)

@login_required
def generate_receipt(request, order_id):
    """Generate receipt for an order"""
    order = get_object_or_404(Order, id=order_id)
    settings = RestaurantSettings.objects.first()
    
    # Create PDF receipt
    buffer = io.BytesIO()
    width, height = 3*inch, 11*inch
    p = canvas.Canvas(buffer, pagesize=(width, height))
    
    # Header
    p.setFont("Helvetica-Bold", 14)
    p.drawCentredString(width/2, height - 0.5*inch, settings.restaurant_name if settings else "Kwan's Restaurant")
    p.setFont("Helvetica", 9)
    p.drawCentredString(width/2, height - 0.7*inch, settings.address if settings else "123 Restaurant St.")
    p.drawCentredString(width/2, height - 0.85*inch, f"Tel: {settings.phone if settings else '(02) 1234-5678'}")
    
    # Order info
    y = height - 1.2*inch
    p.line(0.2*inch, y, width - 0.2*inch, y)
    y -= 0.15*inch
    
    p.setFont("Helvetica", 9)
    p.drawString(0.2*inch, y, f"Order #: {order.order_number}")
    y -= 0.15*inch
    p.drawString(0.2*inch, y, f"Date: {order.order_date.strftime('%Y-%m-%d %H:%M')}")
    y -= 0.15*inch
    if order.cashier:
        p.drawString(0.2*inch, y, f"Cashier: {order.cashier.user.get_full_name()}")
        y -= 0.15*inch
    if order.table_number:
        p.drawString(0.2*inch, y, f"Table: {order.table_number}")
        y -= 0.15*inch
    if order.customer:
        p.drawString(0.2*inch, y, f"Customer: {order.customer}")
        y -= 0.15*inch
    
    # Items
    y -= 0.1*inch
    p.line(0.2*inch, y, width - 0.2*inch, y)
    y -= 0.2*inch
    
    p.setFont("Helvetica-Bold", 9)
    p.drawString(0.2*inch, y, "ITEMS")
    y -= 0.15*inch
    
    p.setFont("Helvetica", 8)
    for item in order.items.all():
        # Item name and quantity
        item_text = f"{item.quantity}x {item.menu_item.name[:25]}"
        if item.size and item.size != 'regular':
            item_text += f" ({item.size})"
        p.drawString(0.2*inch, y, item_text)
        # Price
        p.drawRightString(width - 0.2*inch, y, f"PHP {item.total_price:,.2f}")
        y -= 0.15*inch
        
        # Special instructions
        if item.special_instructions:
            p.setFont("Helvetica-Oblique", 7)
            p.drawString(0.3*inch, y, f"  Note: {item.special_instructions[:30]}")
            y -= 0.12*inch
            p.setFont("Helvetica", 8)
    
    # Totals
    y -= 0.1*inch
    p.line(0.2*inch, y, width - 0.2*inch, y)
    y -= 0.15*inch
    
    p.setFont("Helvetica", 9)
    p.drawString(0.2*inch, y, "Subtotal:")
    p.drawRightString(width - 0.2*inch, y, f"PHP {order.subtotal:,.2f}")
    y -= 0.15*inch
    
    if order.discount_amount > 0:
        p.drawString(0.2*inch, y, f"Discount ({order.discount_type}):")
        p.drawRightString(width - 0.2*inch, y, f"-PHP {order.discount_amount:,.2f}")
        y -= 0.15*inch
    
    p.drawString(0.2*inch, y, "Tax (12% VAT):")
    p.drawRightString(width - 0.2*inch, y, f"PHP {order.tax_amount:,.2f}")
    y -= 0.2*inch
    
    p.setFont("Helvetica-Bold", 10)
    p.drawString(0.2*inch, y, "TOTAL:")
    p.drawRightString(width - 0.2*inch, y, f"PHP {order.total_amount:,.2f}")
    y -= 0.15*inch
    
    p.setFont("Helvetica", 9)
    p.drawString(0.2*inch, y, f"Payment: {order.get_payment_method_display()}")
    
    # Footer
    y = 0.8*inch
    p.setFont("Helvetica", 8)
    p.drawCentredString(width/2, y, "Thank you for dining with us!")
    y -= 0.12*inch
    p.drawCentredString(width/2, y, "Please come again!")
    
    # Save PDF
    p.showPage()
    p.save()
    
    # Return response
    buffer.seek(0)
    response = HttpResponse(buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'inline; filename="receipt_{order.order_number}.pdf"'
    return response

@login_required
def void_order(request, order_id):
    """Void an order (for correcting errors)"""
    if request.method == 'POST':
        order = get_object_or_404(Order, id=order_id)
        reason = request.POST.get('reason', '')
        
        # Only allow voiding recent orders
        if order.status not in ['completed', 'cancelled']:
            order.status = 'cancelled'
            order.notes += f"\n\nVOIDED: {reason} by {request.user.username} at {timezone.now()}"
            order.save()
            
            # Reverse daily sales
            if order.order_date.date() == date.today():
                daily_sales = DailySales.objects.filter(date=date.today()).first()
                if daily_sales:
                    daily_sales.total_orders -= 1
                    daily_sales.total_revenue -= order.total_amount
                    
                    if order.payment_method == 'cash':
                        daily_sales.cash_sales -= order.total_amount
                    elif order.payment_method == 'card':
                        daily_sales.card_sales -= order.total_amount
                    else:
                        daily_sales.digital_sales -= order.total_amount
                    
                    daily_sales.save()
            
            return JsonResponse({'success': True})
        
        return JsonResponse({'success': False, 'error': 'Cannot void this order'})
    
    return JsonResponse({'success': False, 'error': 'Method not allowed'}, status=405)
