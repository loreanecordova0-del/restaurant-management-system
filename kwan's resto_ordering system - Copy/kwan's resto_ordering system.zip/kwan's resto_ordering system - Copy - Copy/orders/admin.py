from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.db import models
from tinymce.widgets import TinyMCE
from .models import (
    # Employee Management
    Employee, TimeLog,
    # Menu Management
    Category, MenuItem, RegularPizza, SicilianPizza, Toppings, Sub, Pasta, Salad, DinnerPlatters,
    # Order Management
    Order, OrderItem, KitchenOrder,
    # Customer Management
    Customer, CustomerFeedback,
    # Sales and Analytics
    DailySales, Inventory,
    # Settings
    RestaurantSettings,
    # Legacy models
    UserOrder, SavedCarts
)

# Employee Management Admin
@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ['employee_id', 'user', 'role', 'phone', 'is_active', 'hire_date']
    list_filter = ['role', 'is_active', 'hire_date']
    search_fields = ['employee_id', 'user__username', 'user__first_name', 'user__last_name', 'phone']
    date_hierarchy = 'hire_date'

@admin.register(TimeLog)
class TimeLogAdmin(admin.ModelAdmin):
    list_display = ['employee', 'clock_in', 'clock_out', 'total_hours']
    list_filter = ['clock_in', 'employee']
    search_fields = ['employee__user__username', 'employee__employee_id']
    date_hierarchy = 'clock_in'

# Menu Management Admin
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['category_title', 'is_active', 'display_order']
    list_filter = ['is_active']
    search_fields = ['category_title']
    ordering = ['display_order', 'category_title']
    formfield_overrides = {
        models.TextField: {'widget': TinyMCE()},
    }

@admin.register(MenuItem)
class MenuItemAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'base_price', 'is_available', 'is_vegetarian', 'is_spicy', 'preparation_time']
    list_filter = ['category', 'is_available', 'is_vegetarian', 'is_spicy']
    search_fields = ['name', 'description']
    list_editable = ['base_price', 'is_available']

# Order Management Admin
class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ['total_price']

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['order_number', 'customer', 'table_number', 'status', 'total_amount', 'order_date', 'is_paid']
    list_filter = ['status', 'payment_method', 'is_paid', 'order_date']
    search_fields = ['order_number', 'customer__first_name', 'customer__last_name']
    date_hierarchy = 'order_date'
    readonly_fields = ['order_number', 'subtotal', 'tax_amount', 'total_amount']
    inlines = [OrderItemInline]
    
    def get_readonly_fields(self, request, obj=None):
        if obj and obj.status == 'completed':
            return self.readonly_fields + ['status', 'payment_method']
        return self.readonly_fields

@admin.register(KitchenOrder)
class KitchenOrderAdmin(admin.ModelAdmin):
    list_display = ['order', 'station', 'status', 'received_at', 'chef']
    list_filter = ['station', 'status', 'received_at']
    search_fields = ['order__order_number']
    date_hierarchy = 'received_at'

# Customer Management Admin
@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ['get_full_name', 'phone', 'email', 'customer_type', 'loyalty_points', 'total_spent', 'visit_count']
    list_filter = ['customer_type', 'created_at']
    search_fields = ['first_name', 'last_name', 'phone', 'email', 'id_number']
    date_hierarchy = 'created_at'
    
    def get_full_name(self, obj):
        return f"{obj.first_name} {obj.last_name}"
    get_full_name.short_description = 'Name'

@admin.register(CustomerFeedback)
class CustomerFeedbackAdmin(admin.ModelAdmin):
    list_display = ['customer', 'order', 'food_rating', 'service_rating', 'ambiance_rating', 'resolved', 'created_at']
    list_filter = ['resolved', 'food_rating', 'service_rating', 'ambiance_rating', 'created_at']
    search_fields = ['customer__first_name', 'customer__last_name', 'comments']
    date_hierarchy = 'created_at'
    
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        # Show unresolved complaints first
        return qs.order_by('resolved', '-created_at')

# Sales and Analytics Admin
@admin.register(DailySales)
class DailySalesAdmin(admin.ModelAdmin):
    list_display = ['date', 'total_orders', 'total_revenue', 'cash_sales', 'card_sales', 'digital_sales', 'best_selling_item']
    list_filter = ['date']
    date_hierarchy = 'date'
    readonly_fields = ['date', 'total_orders', 'total_revenue', 'total_discount', 'total_tax', 
                      'cash_sales', 'card_sales', 'digital_sales', 'best_selling_item']

@admin.register(Inventory)
class InventoryAdmin(admin.ModelAdmin):
    list_display = ['item_name', 'quantity', 'unit', 'reorder_level', 'needs_reorder', 'last_updated']
    list_filter = ['last_updated']
    search_fields = ['item_name']
    list_editable = ['quantity', 'reorder_level']
    
    def needs_reorder(self, obj):
        if obj.quantity <= obj.reorder_level:
            return format_html('<span style="color: red;">⚠️ Yes</span>')
        return format_html('<span style="color: green;">✓ No</span>')
    needs_reorder.short_description = 'Needs Reorder'

# Settings Admin
@admin.register(RestaurantSettings)
class RestaurantSettingsAdmin(admin.ModelAdmin):
    list_display = ['restaurant_name', 'phone', 'email', 'tax_rate', 'pwd_discount', 'senior_discount']
    
    def has_add_permission(self, request):
        # Only allow one restaurant settings object
        if self.model.objects.count() >= 1:
            return False
        return super().has_add_permission(request)

# Legacy Models (keep for backward compatibility)
@admin.register(RegularPizza)
class RegularPizzaAdmin(admin.ModelAdmin):
    list_display = ['pizza_choice', 'small_price', 'large_price']
    formfield_overrides = {
        models.TextField: {'widget': TinyMCE()},
    }

@admin.register(SicilianPizza)
class SicilianPizzaAdmin(admin.ModelAdmin):
    list_display = ['pizza_choice', 'small_price', 'large_price']
    formfield_overrides = {
        models.TextField: {'widget': TinyMCE()},
    }

admin.site.register(Toppings)
admin.site.register(Sub)
admin.site.register(Pasta)
admin.site.register(Salad)
admin.site.register(DinnerPlatters)
admin.site.register(UserOrder)
admin.site.register(SavedCarts)

# Customize admin site header and title
admin.site.site_header = "Kwan's Restaurant Management System"
admin.site.site_title = "Kwan's Admin"
admin.site.index_title = "Welcome to Kwan's Restaurant Management"
