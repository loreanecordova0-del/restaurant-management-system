# Simple POS Order Creation
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from decimal import Decimal
import random
import string
from datetime import datetime

from .models import (
    Customer, Order, RestaurantSettings,
    RegularPizza, SicilianPizza, Sub, Pasta, Salad, DinnerPlatters
)

def generate_order_number():
    """Generate unique order number"""
    timestamp = datetime.now().strftime('%Y%m%d%H%M')
    random_suffix = ''.join(random.choices(string.digits, k=4))
    return f"ORD-{timestamp}-{random_suffix}"

@login_required
def create_simple_order(request):
    """Simple order creation for testing"""
    if request.method == 'POST':
        # Get form data
        customer_id = request.POST.get('customer_id')
        items = request.POST.get('items')
        table_number = request.POST.get('table_number', '1')
        payment_method = request.POST.get('payment_method', 'cash')
        subtotal = Decimal(request.POST.get('subtotal', '0'))
        
        # Get customer
        customer = None
        discount_amount = Decimal('0')
        discount_type = ''
        
        if customer_id:
            try:
                customer = Customer.objects.get(id=customer_id)
                
                # Apply PWD/Senior discount
                if customer.customer_type in ['pwd', 'senior']:
                    discount_percentage = 20  # 20% discount
                    discount_amount = (subtotal * Decimal('20')) / 100
                    discount_type = f"{customer.customer_type.upper()} Discount (20%)"
                    
                # Update customer stats
                customer.visit_count += 1
                customer.last_visit = timezone.now()
                customer.total_spent += (subtotal - discount_amount)
                customer.save()
            except Customer.DoesNotExist:
                pass
        
        # Get restaurant settings
        settings = RestaurantSettings.objects.first()
        if not settings:
            settings = RestaurantSettings.objects.create(
                restaurant_name="Kwan's Restaurant",
                tax_rate=12,
                pwd_discount=20,
                senior_discount=20
            )
        
        # Calculate totals
        after_discount = subtotal - discount_amount
        tax_amount = (after_discount * settings.tax_rate) / 100
        total_amount = after_discount + tax_amount
        
        # Create order
        order = Order.objects.create(
            order_number=generate_order_number(),
            customer=customer,
            table_number=table_number,
            payment_method=payment_method,
            discount_type=discount_type,
            discount_amount=discount_amount,
            subtotal=subtotal,
            tax_amount=tax_amount,
            total_amount=total_amount,
            status='confirmed',
            order_date=timezone.now()
        )
        
        messages.success(request, f'Order {order.order_number} created successfully! Total: ${total_amount:.2f}')
        
        # Update daily sales
        from .models import DailySales
        today = timezone.now().date()
        daily_sales, created = DailySales.objects.get_or_create(
            date=today,
            defaults={'total_revenue': Decimal('0'), 'total_orders': 0}
        )
        daily_sales.total_revenue += total_amount
        daily_sales.total_orders += 1
        daily_sales.save()
        
        return redirect('orders:dashboard')
    
    # For GET request, redirect to POS
    return redirect('orders:pos_interface')
