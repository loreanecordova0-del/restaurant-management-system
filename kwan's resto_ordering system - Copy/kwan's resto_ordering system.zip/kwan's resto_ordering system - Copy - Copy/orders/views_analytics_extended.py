# Extended Analytics Views
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Count, Avg, Q
from django.utils import timezone
from datetime import timedelta
from .models import Order, OrderItem, Customer, MenuItem

def customer_analytics(request):
    """Customer analytics and behavior analysis"""
    from django.db.models import Q
    from .models import Order
    
    # Customer statistics
    total_customers = Customer.objects.count()
    pwd_customers = Customer.objects.filter(customer_type='pwd').count()
    senior_customers = Customer.objects.filter(customer_type='senior').count()
    # Regular is the default customer type
    regular_customers = Customer.objects.filter(customer_type='regular').count()
    
    # If no regular customers marked, count all non-PWD/SENIOR as regular
    if regular_customers == 0 and total_customers > 0:
        regular_customers = total_customers - pwd_customers - senior_customers
    
    # Top customers by spending - filter out null amounts
    top_customers = Customer.objects.annotate(
        total_spent_calc=Sum('order__total_amount'),
        order_count=Count('order')
    ).filter(total_spent_calc__gt=0).order_by('-total_spent_calc')[:10]
    
    # Customer visit frequency
    today = timezone.now().date()
    month_start = today.replace(day=1)
    
    # Active customers - those who made orders this month
    active_this_month = Customer.objects.filter(
        order__order_date__date__gte=month_start
    ).distinct().count()
    
    # If no active customers, check for any orders
    if active_this_month == 0:
        # Count customers with any orders
        active_this_month = Customer.objects.filter(
            order__isnull=False
        ).distinct().count()
    
    # New customers this month
    new_customers = Customer.objects.filter(
        created_at__date__gte=month_start
    ).count()
    
    # Customer type spending breakdown for bar chart
    type_spending = {
        'regular': {'count': 0, 'revenue': 0, 'customers': 0},
        'pwd': {'count': 0, 'revenue': 0, 'customers': 0},
        'senior': {'count': 0, 'revenue': 0, 'customers': 0}
    }
    
    # Get spending by customer type - include ALL orders regardless of status
    for customer_type in ['regular', 'pwd', 'senior']:
        customers = Customer.objects.filter(customer_type=customer_type)
        customer_count = customers.count()
        orders = Order.objects.filter(customer__in=customers)
        total_revenue = orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
        order_count = orders.count()
        
        type_spending[customer_type] = {
            'count': order_count,
            'revenue': float(total_revenue),
            'customers': customer_count
        }
    
    # Calculate total revenue across all types
    total_revenue = sum([type_spending[t]['revenue'] for t in type_spending])
    total_orders = sum([type_spending[t]['count'] for t in type_spending])
    
    # Convert to list to ensure proper evaluation in template
    top_customers_list = list(top_customers)
    
    context = {
        'total_customers': total_customers,
        'pwd_customers': pwd_customers,
        'senior_customers': senior_customers,
        'regular_customers': regular_customers,
        'top_customers': top_customers_list,  # Keep as top_customers for template compatibility
        'active_this_month': active_this_month,
        'new_customers': new_customers,
        'type_spending': type_spending,
        'total_revenue': total_revenue,
        'total_orders': total_orders
    }
    
    return render(request, 'orders/customer_analytics.html', context)

def menu_analytics(request):
    """Menu item performance analytics"""
    # Get date range
    end_date = timezone.now().date()
    start_date = end_date - timedelta(days=30)
    
    # Get all orders in date range
    orders_in_range = Order.objects.filter(
        order_date__date__range=[start_date, end_date],
        status__in=['completed', 'served', 'pending']
    )
    
    # Top selling items - include all items with sales
    top_items = OrderItem.objects.filter(
        order__in=orders_in_range
    ).values('menu_item__name').annotate(
        total_quantity=Sum('quantity'),
        total_revenue=Sum('total_price'),
        order_count=Count('order', distinct=True)
    ).filter(menu_item__name__isnull=False).order_by('-total_revenue')[:15]
    
    # If no items in last 30 days, get all time top items
    if not top_items:
        top_items = OrderItem.objects.values('menu_item__name').annotate(
            total_quantity=Sum('quantity'),
            total_revenue=Sum('total_price'),
            order_count=Count('order', distinct=True)
        ).filter(menu_item__name__isnull=False).order_by('-total_revenue')[:15]
    
    # Least selling items
    least_items = OrderItem.objects.filter(
        order__in=orders_in_range
    ).values('menu_item__name').annotate(
        total_quantity=Sum('quantity'),
        total_revenue=Sum('total_price')
    ).filter(menu_item__name__isnull=False).order_by('total_quantity')[:10]
    
    # Category performance
    category_performance = OrderItem.objects.filter(
        order__in=orders_in_range
    ).values('menu_item__category__category_title').annotate(
        total_quantity=Sum('quantity'),
        total_revenue=Sum('total_price')
    ).exclude(menu_item__category__category_title__isnull=True).order_by('-total_revenue')
    
    context = {
        'top_items': top_items,
        'least_items': least_items,
        'category_performance': category_performance,
        'start_date': start_date,
        'end_date': end_date
    }
    return render(request, 'orders/menu_analytics.html', context)
