from django.core.management.base import BaseCommand
from orders.models import Customer, Order
from django.db.models import Sum, Count

class Command(BaseCommand):
    help = 'Check customer analytics data'

    def handle(self, *args, **kwargs):
        self.stdout.write("\n=== CUSTOMER DATA CHECK ===\n")

        # Check customers
        customers = Customer.objects.all()
        self.stdout.write(f"Total Customers: {customers.count()}\n")

        for customer in customers:
            self.stdout.write(f"\n{customer.first_name} {customer.last_name}")
            self.stdout.write(f"  Type: {customer.customer_type}")
            orders = Order.objects.filter(customer=customer)
            self.stdout.write(f"  Orders: {orders.count()}")
            total = orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
            self.stdout.write(f"  Total Spent: ${total}\n")

        self.stdout.write("\n=== SPENDING BY TYPE ===\n")

        for customer_type in ['regular', 'pwd', 'senior']:
            customers_of_type = Customer.objects.filter(customer_type=customer_type)
            orders = Order.objects.filter(customer__in=customers_of_type)
            total_revenue = orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
            order_count = orders.count()
            
            self.stdout.write(
                self.style.SUCCESS(f"\n{customer_type.upper()}:")
            )
            self.stdout.write(f"  Customers: {customers_of_type.count()}")
            self.stdout.write(f"  Orders: {order_count}")
            self.stdout.write(f"  Revenue: ${total_revenue:.2f}")
        
        self.stdout.write("\n\n✅ Data check complete!\n")
