from django.core.management.base import BaseCommand
from orders.models import Customer, MenuItem, Order, OrderItem
from django.utils import timezone
from decimal import Decimal

class Command(BaseCommand):
    help = 'Creates a sample order for testing'

    def handle(self, *args, **kwargs):
        # Check if we have customers and menu items
        customers = Customer.objects.all()
        menu_items = MenuItem.objects.filter(is_available=True)
        
        if not customers.exists():
            self.stdout.write(
                self.style.ERROR('❌ No customers found! Run: python manage.py create_sample_customers')
            )
            return
        
        if not menu_items.exists():
            self.stdout.write(
                self.style.ERROR('❌ No menu items found! Please add menu items in admin first.')
            )
            return
        
        # Get first customer
        customer = customers.first()
        
        # Create order
        order = Order.objects.create(
            customer=customer,
            order_date=timezone.now(),
            status='completed',
            payment_method='cash',
            table_number='Table 1'
        )
        
        # Add some items
        items_to_add = menu_items[:3]  # Get first 3 menu items
        subtotal = Decimal('0')
        
        for item in items_to_add:
            quantity = 2
            total_price = item.price * quantity
            
            OrderItem.objects.create(
                order=order,
                menu_item=item,
                quantity=quantity,
                price=item.price,
                total_price=total_price
            )
            subtotal += total_price
        
        # Calculate totals
        discount = Decimal('0')
        if customer.customer_type in ['pwd', 'senior']:
            discount = subtotal * Decimal('0.20')  # 20% discount
        
        tax = (subtotal - discount) * Decimal('0.12')  # 12% VAT
        total = subtotal - discount + tax
        
        # Update order
        order.subtotal = subtotal
        order.discount_amount = discount
        order.tax_amount = tax
        order.total_amount = total
        order.save()
        
        self.stdout.write(
            self.style.SUCCESS(f'\n✅ Order created successfully!')
        )
        self.stdout.write(
            self.style.SUCCESS(f'   Order ID: {order.id}')
        )
        self.stdout.write(
            self.style.SUCCESS(f'   Customer: {customer.first_name} {customer.last_name} ({customer.customer_type})')
        )
        self.stdout.write(
            self.style.SUCCESS(f'   Items: {order.items.count()}')
        )
        self.stdout.write(
            self.style.SUCCESS(f'   Subtotal: ${subtotal:.2f}')
        )
        self.stdout.write(
            self.style.SUCCESS(f'   Discount: ${discount:.2f}')
        )
        self.stdout.write(
            self.style.SUCCESS(f'   Tax: ${tax:.2f}')
        )
        self.stdout.write(
            self.style.SUCCESS(f'   Total: ${total:.2f}')
        )
        
        # Show analytics status
        total_orders = Order.objects.count()
        self.stdout.write(
            self.style.SUCCESS(f'\n📊 Total orders in database: {total_orders}')
        )
        self.stdout.write(
            self.style.SUCCESS('✅ Now check your analytics at http://127.0.0.1:8000/sales/dashboard/')
        )
