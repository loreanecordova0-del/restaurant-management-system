from django.core.management.base import BaseCommand
from orders.models import Customer, Order
from django.db.models import Sum, Count

class Command(BaseCommand):
    help = 'Debug customer analytics data issues'

    def handle(self, *args, **kwargs):
        self.stdout.write("\n=== DEBUGGING CUSTOMER ANALYTICS ===\n")

        # Check top customers query
        self.stdout.write("Testing top_customers query:")
        top_customers = Customer.objects.annotate(
            total_spent_calc=Sum('order__total_amount'),
            order_count=Count('order')
        ).filter(total_spent_calc__gt=0).order_by('-total_spent_calc')[:10]
        
        self.stdout.write(f"Found {top_customers.count()} customers with orders\n")
        
        for customer in top_customers:
            self.stdout.write(
                self.style.SUCCESS(
                    f"✅ {customer.first_name} {customer.last_name} - "
                    f"Type: {customer.customer_type} - "
                    f"Orders: {customer.order_count} - "
                    f"Spent: ${customer.total_spent_calc:.2f}"
                )
            )
        
        # Check if issue is with annotation
        self.stdout.write("\n\nChecking ALL customers:")
        all_customers = Customer.objects.all()
        for customer in all_customers:
            orders = Order.objects.filter(customer=customer)
            total = orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
            self.stdout.write(
                f"{customer.first_name} {customer.last_name} - "
                f"{orders.count()} orders - ${total:.2f}"
            )
        
        # Check Order model
        self.stdout.write("\n\nChecking ALL orders:")
        all_orders = Order.objects.all()
        self.stdout.write(f"Total orders in database: {all_orders.count()}")
        
        for order in all_orders:
            self.stdout.write(
                f"Order #{order.id} - Customer: {order.customer.first_name if order.customer else 'None'} - "
                f"Amount: ${order.total_amount} - Status: {order.status}"
            )
        
        self.stdout.write("\n✅ Debug complete!\n")
