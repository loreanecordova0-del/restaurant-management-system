from django.core.management.base import BaseCommand
from orders.models import Customer
from datetime import datetime, date

class Command(BaseCommand):
    help = 'Creates sample customers for testing'

    def handle(self, *args, **kwargs):
        customers_data = [
            {
                'first_name': 'John',
                'last_name': 'Doe',
                'email': 'john.doe@email.com',
                'phone': '09171234567',
                'customer_type': 'regular',
                'notes': '123 Main St, Manila'
            },
            {
                'first_name': 'Maria',
                'last_name': 'Santos',
                'email': 'maria.santos@email.com',
                'phone': '09181234567',
                'customer_type': 'pwd',
                'id_number': 'PWD-2024-001',
                'notes': '456 Rizal Ave, Quezon City'
            },
            {
                'first_name': 'Pedro',
                'last_name': 'Garcia',
                'email': 'pedro.garcia@email.com',
                'phone': '09191234567',
                'customer_type': 'senior',
                'id_number': 'SC-2024-001',
                'date_of_birth': date(1960, 5, 15),
                'notes': '789 Bonifacio St, Makati'
            },
            {
                'first_name': 'Jane',
                'last_name': 'Smith',
                'email': 'jane.smith@email.com',
                'phone': '09201234567',
                'customer_type': 'regular',
                'notes': '321 Luna St, Pasig'
            },
        ]

        created_count = 0
        for data in customers_data:
            customer, created = Customer.objects.get_or_create(
                email=data['email'],
                defaults=data
            )
            if created:
                created_count += 1
                self.stdout.write(
                    self.style.SUCCESS(f'Created customer: {customer.first_name} {customer.last_name} ({customer.customer_type.upper()})')
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f'Customer already exists: {customer.first_name} {customer.last_name}')
                )

        self.stdout.write(
            self.style.SUCCESS(f'\n✅ Total customers created: {created_count}')
        )
        self.stdout.write(
            self.style.SUCCESS(f'✅ Total customers in database: {Customer.objects.count()}')
        )
        
        # Show breakdown by type
        regular_count = Customer.objects.filter(customer_type='regular').count()
        pwd_count = Customer.objects.filter(customer_type='pwd').count()
        senior_count = Customer.objects.filter(customer_type='senior').count()
        
        self.stdout.write(
            self.style.SUCCESS(f'\n📊 Customer breakdown:')
        )
        self.stdout.write(
            self.style.SUCCESS(f'   Regular: {regular_count}')
        )
        self.stdout.write(
            self.style.SUCCESS(f'   PWD: {pwd_count}')
        )
        self.stdout.write(
            self.style.SUCCESS(f'   Senior: {senior_count}')
        )
