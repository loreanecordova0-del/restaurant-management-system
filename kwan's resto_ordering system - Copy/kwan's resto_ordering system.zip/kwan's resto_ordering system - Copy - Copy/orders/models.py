from django.db import models
from datetime import datetime
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone
import qrcode
from io import BytesIO
from django.core.files import File
from PIL import Image

# Create your models here.

# Employee Management Models
class Employee(models.Model):
    ROLE_CHOICES = [
        ('manager', 'Manager'),
        ('cashier', 'Cashier'),
        ('chef', 'Chef'),
        ('waiter', 'Waiter'),
        ('kitchen_staff', 'Kitchen Staff'),
        ('admin', 'Admin'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='employee_profile')
    employee_id = models.CharField(max_length=20, unique=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    phone = models.CharField(max_length=15)
    address = models.TextField()
    hire_date = models.DateField(default=timezone.now)
    is_active = models.BooleanField(default=True)
    hourly_rate = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    
    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.user.get_full_name()} - {self.employee_id}"

class TimeLog(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='time_logs')
    clock_in = models.DateTimeField()
    clock_out = models.DateTimeField(null=True, blank=True)
    break_start = models.DateTimeField(null=True, blank=True)
    break_end = models.DateTimeField(null=True, blank=True)
    scheduled_break_start = models.DateTimeField(null=True, blank=True, help_text="Scheduled break start time (admin-assigned)")
    scheduled_break_end = models.DateTimeField(null=True, blank=True, help_text="Scheduled break end time (auto 30min)")
    cover_employee = models.ForeignKey('Employee', null=True, blank=True, related_name='covering_breaks', help_text="Which employee is assigned to cover this break?", on_delete=models.SET_NULL)
    total_hours = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    
    def calculate_hours(self):
        if self.clock_in and self.clock_out:
            delta = self.clock_out - self.clock_in
            hours = delta.total_seconds() / 3600
            if self.break_start and self.break_end:
                break_delta = self.break_end - self.break_start
                break_hours = break_delta.total_seconds() / 3600
                hours -= break_hours
            self.total_hours = round(hours, 2)
            return self.total_hours
        return 0
    
    def __str__(self):
        return f"{self.employee} - {self.clock_in.date()}"

# Menu Management Models
class Category(models.Model):
    category_title = models.CharField(max_length=200)
    category_image = models.ImageField(upload_to='categories/', null=True, blank=True)
    category_description = models.TextField()
    is_active = models.BooleanField(default=True)
    display_order = models.IntegerField(default=0)
    
    class Meta:
        ordering = ['display_order', 'category_title']
        verbose_name_plural = 'Categories'
    
    def __str__(self):
        return self.category_title

class MenuItem(models.Model):
    SIZE_CHOICES = [
        ('small', 'Small'),
        ('medium', 'Medium'),
        ('large', 'Large'),
        ('regular', 'Regular'),
    ]
    
    name = models.CharField(max_length=200)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='menu_items')
    description = models.TextField()
    image = models.ImageField(upload_to='menu_items/', null=True, blank=True)
    base_price = models.DecimalField(max_digits=8, decimal_places=2)
    sizes_available = models.JSONField(default=dict, blank=True)  # {"small": 10.99, "large": 15.99}
    is_available = models.BooleanField(default=True)
    preparation_time = models.IntegerField(help_text="Preparation time in minutes", default=15)
    calories = models.IntegerField(null=True, blank=True)
    is_vegetarian = models.BooleanField(default=False)
    is_spicy = models.BooleanField(default=False)
    allergens = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.name} - {self.category.category_title}"

class RegularPizza(models.Model):
    #example row :: 1 topping , 5.00 , 7.00
    pizza_choice = models.CharField(max_length=200)
    small_price = models.DecimalField(max_digits=6, decimal_places=2)
    large_price = models.DecimalField(max_digits=6, decimal_places=2)
    category_description = models.TextField() #make this the wysiwyg text field

    def __str__(self):
        #overriding the string method to get a good representation of it in string format
        return f"Regular Pizza : {self.pizza_choice}"

class SicilianPizza(models.Model):
    #example row :: 1 topping , 5.00 , 7.00
    pizza_choice = models.CharField(max_length=200)
    small_price = models.DecimalField(max_digits=6, decimal_places=2)
    large_price = models.DecimalField(max_digits=6, decimal_places=2)
    category_description = models.TextField() #make this the wysiwyg text field

    def __str__(self):
        #overriding the string method to get a good representation of it in string format
        return f"Sicilian Pizza : {self.pizza_choice}"

class Toppings(models.Model):
    #example row :: Pepperoni
    topping_name = models.CharField(max_length=200)

    def __str__(self):
        #overriding the string method to get a good representation of it in string format
        return f"{self.topping_name}"


class Sub(models.Model):
    #example row :: meatball , 5.00 , 6.50
    sub_filling = models.CharField(max_length=200)
    small_price = models.DecimalField(max_digits=6, decimal_places=2)
    large_price = models.DecimalField(max_digits=6, decimal_places=2)

    def __str__(self):
        #overriding the string method to get a good representation of it in string format
        return f"Sub : {self.sub_filling}"

class Pasta(models.Model):
    dish_name = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=6, decimal_places=2)

    def __str__(self):
        #overriding the string method to get a good representation of it in string format
        return f"{self.dish_name}"


class Salad(models.Model):
    dish_name = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=6, decimal_places=2)

    def __str__(self):
        #overriding the string method to get a good representation of it in string format
        return f"Salad : {self.dish_name}"



class DinnerPlatters(models.Model):
    dish_name = models.CharField(max_length=200)
    small_price = models.DecimalField(max_digits=6, decimal_places=2)
    large_price = models.DecimalField(max_digits=6, decimal_places=2)

    def __str__(self):
        #overriding the string method to get a good representation of it in string format
        return f"Platter : {self.dish_name}"

# Enhanced Order Management
class Order(models.Model):
    ORDER_STATUS = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('preparing', 'Preparing'),
        ('ready', 'Ready'),
        ('served', 'Served'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ]
    
    PAYMENT_METHOD = [
        ('cash', 'Cash'),
        ('card', 'Card'),
        ('gcash', 'GCash'),
        ('maya', 'Maya'),
    ]
    
    order_number = models.CharField(max_length=20, unique=True)
    customer = models.ForeignKey('Customer', on_delete=models.SET_NULL, null=True, blank=True)
    table_number = models.IntegerField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=ORDER_STATUS, default='pending')
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD, default='cash')
    subtotal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    discount_type = models.CharField(max_length=50, blank=True)  # PWD, Senior Citizen
    tax_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    cashier = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, related_name='processed_orders')
    order_date = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)
    is_paid = models.BooleanField(default=False)
    
    def calculate_totals(self):
        self.subtotal = sum(item.total_price for item in self.items.all())
        self.tax_amount = self.subtotal * 0.12  # 12% VAT
        self.total_amount = self.subtotal + self.tax_amount - self.discount_amount
        self.save()
    
    def __str__(self):
        return f"Order #{self.order_number} - {self.order_date.strftime('%Y-%m-%d %H:%M')}"

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    size = models.CharField(max_length=20, blank=True)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    total_price = models.DecimalField(max_digits=10, decimal_places=2)
    special_instructions = models.TextField(blank=True)
    is_sent_to_kitchen = models.BooleanField(default=False)
    prepared_at = models.DateTimeField(null=True, blank=True)
    
    def save(self, *args, **kwargs):
        self.total_price = self.price * self.quantity
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.menu_item.name} x {self.quantity}"

# Customer Relationship Management
class Customer(models.Model):
    CUSTOMER_TYPE = [
        ('regular', 'Regular'),
        ('pwd', 'PWD'),
        ('senior', 'Senior Citizen'),
    ]
    
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True, null=True, blank=True)
    phone = models.CharField(max_length=15)
    customer_type = models.CharField(max_length=20, choices=CUSTOMER_TYPE, default='regular')
    id_number = models.CharField(max_length=50, blank=True)  # For PWD or Senior ID
    date_of_birth = models.DateField(null=True, blank=True)
    loyalty_points = models.IntegerField(default=0)
    total_spent = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    visit_count = models.IntegerField(default=0)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    last_visit = models.DateTimeField(null=True, blank=True)
    
    def get_discount_percentage(self):
        if self.customer_type in ['pwd', 'senior']:
            return 20  # 20% discount for PWD and Senior Citizens
        return 0
    
    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.customer_type.upper()}"

class CustomerFeedback(models.Model):
    RATING_CHOICES = [
        (1, '1 - Poor'),
        (2, '2 - Fair'),
        (3, '3 - Good'),
        (4, '4 - Very Good'),
        (5, '5 - Excellent'),
    ]
    
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='feedbacks')
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='feedback')
    food_rating = models.IntegerField(choices=RATING_CHOICES)
    service_rating = models.IntegerField(choices=RATING_CHOICES)
    ambiance_rating = models.IntegerField(choices=RATING_CHOICES)
    comments = models.TextField(blank=True)
    response = models.TextField(blank=True)  # Staff response to complaint
    resolved = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    resolved_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True)
    
    def __str__(self):
        return f"Feedback from {self.customer} - {self.created_at.date()}"

# Sales and Analytics
class DailySales(models.Model):
    date = models.DateField(unique=True)
    total_orders = models.IntegerField(default=0)
    total_revenue = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total_discount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_tax = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    cash_sales = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    card_sales = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    digital_sales = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    best_selling_item = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Sales for {self.date} - PHP {self.total_revenue}"

# Kitchen Display System
class KitchenOrder(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='kitchen_orders')
    station = models.CharField(max_length=50)  # e.g., 'Hot Kitchen', 'Cold Kitchen', 'Drinks'
    items = models.JSONField()
    status = models.CharField(max_length=20, default='pending')
    received_at = models.DateTimeField(auto_now_add=True)
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    chef = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True)
    
    def __str__(self):
        return f"Kitchen Order for {self.order.order_number} - {self.station}"

# Inventory Basic Management
class Inventory(models.Model):
    item_name = models.CharField(max_length=200)
    unit = models.CharField(max_length=50)
    quantity = models.DecimalField(max_digits=10, decimal_places=2)
    reorder_level = models.DecimalField(max_digits=10, decimal_places=2)
    last_updated = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.item_name} - {self.quantity} {self.unit}"

# Keep existing models but update them
class UserOrder(models.Model):
    username = models.CharField(max_length=200)
    order = models.TextField()
    price = models.DecimalField(max_digits=6, decimal_places=2)
    time_of_order = models.DateTimeField(default=datetime.now, blank=True)
    delivered = models.BooleanField()
    
    def __str__(self):
        return f"Legacy Order by {self.username} on {self.time_of_order.date()}"

class SavedCarts(models.Model):
    username = models.CharField(max_length=200, primary_key=True)
    cart = models.TextField()
    
    def __str__(self):
        return f"Saved cart for {self.username}"

# Settings Model
class RestaurantSettings(models.Model):
    restaurant_name = models.CharField(max_length=200, default="Kwan's Restaurant")
    address = models.TextField()
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    tax_rate = models.DecimalField(max_digits=5, decimal_places=2, default=12.00)
    service_charge = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    pwd_discount = models.DecimalField(max_digits=5, decimal_places=2, default=20.00)
    senior_discount = models.DecimalField(max_digits=5, decimal_places=2, default=20.00)
    opening_time = models.TimeField(default="10:00")
    closing_time = models.TimeField(default="22:00")
    
    class Meta:
        verbose_name_plural = "Restaurant Settings"
    
    def __str__(self):
        return self.restaurant_name
