from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.db.models import Sum, Count, Q, Avg
from django.utils import timezone
from datetime import date, timedelta
import json

# Import all models
from .models import (
    Order, OrderItem, MenuItem, Category,
    Customer, CustomerFeedback,
    Employee, TimeLog,
    DailySales, KitchenOrder,
    RestaurantSettings
)

# Import views from modular files
from .views_pos import *
from .views_employee import *
from .views_analytics import *
from .views_customer import *
from .views_kitchen import *
from .views_menu import *

# Dashboard and Main Views
@login_required
def dashboard(request):
    """Main dashboard with real-time statistics"""
    today = date.today()
    context = {}
    
    # Today's performance
    today_orders = Order.objects.filter(order_date__date=today)
    context['today_orders_count'] = today_orders.count()
    context['today_revenue'] = today_orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    context['pending_orders'] = today_orders.filter(status='pending').count()
    context['active_orders'] = today_orders.filter(status__in=['confirmed', 'preparing', 'ready']).count()
    
    # Employee status
    context['active_employees'] = TimeLog.objects.filter(
        clock_in__date=today,
        clock_out__isnull=True
    ).count()
    
    # Customer statistics
    context['total_customers'] = Customer.objects.count()
    context['pwd_customers'] = Customer.objects.filter(customer_type='pwd').count()
    context['senior_customers'] = Customer.objects.filter(customer_type='senior').count()
    
    # Customer feedback alerts
    context['unresolved_complaints'] = CustomerFeedback.objects.filter(
        resolved=False
    ).count()
    
    # Low ratings alert
    context['critical_feedback'] = CustomerFeedback.objects.filter(
        Q(food_rating__lte=2) | Q(service_rating__lte=2) | Q(ambiance_rating__lte=2),
        resolved=False
    ).count()
    
    # Top selling items today
    top_items = OrderItem.objects.filter(
        order__order_date__date=today
    ).values('menu_item__name').annotate(
        total_qty=Sum('quantity')
    ).order_by('-total_qty')[:5]
    context['top_items'] = top_items
    
    # Recent orders
    context['recent_orders'] = Order.objects.order_by('-order_date')[:5]
    
    # Compare with yesterday
    yesterday = today - timedelta(days=1)
    yesterday_revenue = Order.objects.filter(
        order_date__date=yesterday
    ).aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    
    if yesterday_revenue > 0:
        context['revenue_change'] = ((context['today_revenue'] - yesterday_revenue) / yesterday_revenue) * 100
    else:
        context['revenue_change'] = 100 if context['today_revenue'] > 0 else 0
    
    # Monthly statistics
    month_start = today.replace(day=1)
    month_orders = Order.objects.filter(
        order_date__date__gte=month_start
    )
    context['month_revenue'] = month_orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    context['month_orders'] = month_orders.count()
    
    return render(request, 'orders/dashboard.html', context)

def index(request):
    """Landing page for restaurant system"""
    if request.user.is_authenticated:
        return redirect('orders:dashboard')
    return render(request, 'orders/index.html', {})

def login_view(request):
    """Login view with employee authentication"""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            messages.success(request, f'Welcome back, {user.get_full_name() or user.username}!')
            
            # Check if user is employee and redirect appropriately
            if hasattr(user, 'employee_profile'):
                role = user.employee_profile.role
                if role in ['cashier', 'waiter']:
                    return redirect('orders:pos_interface')
                elif role in ['chef', 'kitchen_staff']:
                    return redirect('orders:kitchen_display')
                elif role in ['manager', 'admin']:
                    return redirect('orders:dashboard')
            
            return redirect('orders:dashboard')
        else:
            messages.error(request, 'Invalid username or password!')
    
    return render(request, 'orders/login.html', {})

def logout_view(request):
    """Logout view"""
    logout(request)
    messages.info(request, 'You have been logged out successfully.')
    return redirect('orders:index')

# Menu Views
def menu_view(request):
    """Display menu for ordering - shows all food items"""
    from .models import RegularPizza, SicilianPizza, Sub, Pasta, Salad, DinnerPlatters, Toppings
    
    context = {
        'regular_pizzas': RegularPizza.objects.all(),
        'sicilian_pizzas': SicilianPizza.objects.all(),
        'subs': Sub.objects.all(),
        'pastas': Pasta.objects.all(),
        'salads': Salad.objects.all(),
        'platters': DinnerPlatters.objects.all(),
        'toppings': Toppings.objects.all(),
        'categories': Category.objects.filter(is_active=True).order_by('display_order'),
    }
    return render(request, 'orders/menu.html', context)

@login_required
def order_list(request):
    """List all orders with filters"""
    orders = Order.objects.all().order_by('-order_date')
    
    # Apply filters
    status = request.GET.get('status')
    if status:
        orders = orders.filter(status=status)
    
    date_filter = request.GET.get('date')
    if date_filter:
        orders = orders.filter(order_date__date=date_filter)
    
    context = {
        'orders': orders[:50],  # Limit to recent 50
        'order_statuses': Order.ORDER_STATUS
    }
    return render(request, 'orders/order_list.html', context)

# Quick access views for specific features
@login_required
def quick_order(request):
    """Quick order entry for walk-in customers"""
    if request.method == 'POST':
        # Process quick order
        items = json.loads(request.POST.get('items', '[]'))
        table_number = request.POST.get('table_number')
        
        # Create order
        order = Order.objects.create(
            order_number=generate_order_number(),
            table_number=table_number,
            cashier=request.user.employee_profile if hasattr(request.user, 'employee_profile') else None,
            status='confirmed'
        )
        
        # Add items
        for item_data in items:
            menu_item = MenuItem.objects.get(id=item_data['id'])
            OrderItem.objects.create(
                order=order,
                menu_item=menu_item,
                quantity=item_data['quantity'],
                price=menu_item.base_price
            )
        
        order.calculate_totals()
        messages.success(request, f'Order {order.order_number} created!')
        return redirect('orders:order_detail', order_id=order.id)
    
    # Get frequently ordered items
    frequent_items = MenuItem.objects.filter(
        is_available=True
    ).annotate(
        order_count=Count('orderitem')
    ).order_by('-order_count')[:10]
    
    context = {
        'frequent_items': frequent_items,
        'tables': range(1, 21)
    }
    return render(request, 'orders/quick_order.html', context)

def directions(request):
    """View function for the restaurant directions page"""
    context = {
        'title': 'How to Find Us',
        'address': '123 Restaurant Street',
        'city': 'City Name',
        'postal_code': '12345'
    }
    return render(request, 'orders/directions.html', context)

def hours(request):
    """View function for the restaurant hours page"""
    context = {
        'title': 'Business Hours',
        'hours': {
            'Monday-Friday': '10:00 AM - 10:00 PM',
            'Saturday': '11:00 AM - 11:00 PM', 
            'Sunday': '11:00 AM - 9:00 PM'
        }
    }
    return render(request, 'orders/hours.html', context)

def contact(request):
    """View function for contact page"""
    context = {
        'title': 'Contact Us',
        'phone': '+1 234-567-8900',
        'email': 'info@kwansrestaurant.com',
        'address': '123 Restaurant Street, City, State 12345'
    }
    return render(request, 'orders/contact.html', context)

def reports(request):
    """Reports and analytics dashboard"""
    from django.db.models import Sum, Count
    today = timezone.now().date()
    
    # Quick stats
    today_orders = Order.objects.filter(order_date__date=today)
    today_revenue = today_orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    
    context = {
        'today_revenue': today_revenue,
        'today_orders': today_orders.count(),
        'active_employees': Employee.objects.filter(is_active=True).count(),
        'total_customers': Customer.objects.count()
    }
    # Use the main reports dashboard template
    return render(request, 'orders/reports_dashboard.html', context)

@login_required
def settings(request):
    """System settings"""
    settings = RestaurantSettings.objects.first()
    if not settings:
        settings = RestaurantSettings.objects.create(
            restaurant_name="Kwan's Restaurant",
            address="123 Restaurant Street",
            phone="(02) 1234-5678",
            email="info@kwansrestaurant.com"
        )
    
    if request.method == 'POST':
        settings.restaurant_name = request.POST.get('restaurant_name')
        settings.address = request.POST.get('address')
        settings.phone = request.POST.get('phone')
        settings.email = request.POST.get('email')
        settings.tax_rate = request.POST.get('tax_rate', 12)
        settings.pwd_discount = request.POST.get('pwd_discount', 20)
        settings.senior_discount = request.POST.get('senior_discount', 20)
        settings.save()
        
        messages.success(request, 'Settings updated successfully!')
        return redirect('orders:settings')
    
    return render(request, 'orders/settings.html', {'settings': settings})

@login_required
def order_detail(request, order_id):
    """Detailed view of a specific order"""
    order = get_object_or_404(Order, id=order_id)
    context = {
        'order': order,
        'items': order.items.all(),
        'kitchen_orders': order.kitchen_orders.all() if hasattr(order, 'kitchen_orders') else [],
    }
    return render(request, 'orders/order_detail.html', context)

@login_required
@require_POST
def update_order_status(request, order_id):
    """Update order status"""
    order = get_object_or_404(Order, id=order_id)
    new_status = request.POST.get('status')
    
    if new_status in dict(Order.ORDER_STATUS):
        order.status = new_status
        if new_status == 'completed':
            order.completed_at = timezone.now()
            order.is_paid = True
        order.save()
        
        return JsonResponse({'success': True})
    
    return JsonResponse({'success': False, 'error': 'Invalid status'})
