# Sales Analytics Views - Solving Problem #2: Miscounted in tracking sales
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.http import JsonResponse, HttpResponse
from django.db.models import Sum, Count, Avg, Q, F
from django.utils import timezone
from datetime import datetime, timedelta, date
import json
from decimal import Decimal
import pandas as pd
import io
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch

from .models import Order, OrderItem, DailySales, MenuItem, Category, Customer

def is_manager(user):
    """Check if user is manager or superuser"""
    if user.is_superuser:
        return True
    if hasattr(user, 'employee_profile'):
        return user.employee_profile.role in ['manager', 'admin']
    return False

def sales_dashboard(request):
    """Main sales analytics dashboard with real-time tracking"""
    today = date.today()
    
    # Date range from request or default to last 30 days
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    
    if not start_date:
        start_date = today - timedelta(days=30)
    else:
        start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
    
    if not end_date:
        end_date = today
    else:
        end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
    
    # Get orders in date range
    orders = Order.objects.filter(
        order_date__date__range=[start_date, end_date],
        status__in=['completed', 'served']
    )
    
    # Key Metrics
    context = {
        'total_revenue': orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0,
        'total_orders': orders.count(),
        'average_order_value': orders.aggregate(Avg('total_amount'))['total_amount__avg'] or 0,
        'total_customers': orders.values('customer').distinct().count(),
        'total_discount_given': orders.aggregate(Sum('discount_amount'))['discount_amount__sum'] or 0,
        'total_tax_collected': orders.aggregate(Sum('tax_amount'))['tax_amount__sum'] or 0,
        'start_date': start_date,
        'end_date': end_date
    }
    
    # Today's performance
    todays_all_orders = Order.objects.filter(order_date__date=today)
    context['todays_revenue'] = todays_all_orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    context['todays_orders'] = todays_all_orders.count()
    
    # Week and month calculations
    week_start = today - timedelta(days=today.weekday())
    month_start = today.replace(day=1)
    
    week_orders = Order.objects.filter(
        order_date__date__gte=week_start,
        status__in=['completed', 'served', 'pending']
    )
    context['week_revenue'] = week_orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    context['week_orders'] = week_orders.count()
    
    month_orders = Order.objects.filter(
        order_date__date__gte=month_start,
        status__in=['completed', 'served', 'pending']
    )
    context['month_revenue'] = month_orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    context['month_orders'] = month_orders.count()
    
    # Average order value
    avg_value = orders.aggregate(Avg('total_amount'))['total_amount__avg'] or 0
    context['avg_order_value'] = avg_value if avg_value > 0 else 0
    
    # Daily sales chart data - Last 7 days
    daily_revenue = []
    for i in range(7):
        current_date = end_date - timedelta(days=6-i)
        # Get ALL orders for this date (not just from filtered range)
        day_orders = Order.objects.filter(order_date__date=current_date)
        revenue = day_orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
        daily_revenue.append({
            'date': current_date,
            'revenue': float(revenue),
            'orders': day_orders.count()
        })
    
    context['daily_revenue'] = daily_revenue
    context['daily_sales_chart'] = {
        'labels': [d['date'].strftime('%Y-%m-%d') for d in daily_revenue],
        'revenue': [d['revenue'] for d in daily_revenue],
        'orders': [d['orders'] for d in daily_revenue]
    }
    
    # Top selling items - show all time if no recent data
    top_items = OrderItem.objects.filter(
        order__in=orders
    ).values('menu_item__name').annotate(
        total_quantity=Sum('quantity'),
        total_revenue=Sum('total_price')
    ).exclude(menu_item__name__isnull=True).order_by('-total_revenue')[:10]
    
    # If no items in date range, get all-time top items
    if not top_items.exists():
        top_items = OrderItem.objects.values('menu_item__name').annotate(
            total_quantity=Sum('quantity'),
            total_revenue=Sum('total_price')
        ).exclude(menu_item__name__isnull=True).order_by('-total_revenue')[:10]
    
    context['top_items'] = top_items
    
    # Least selling items (for inventory management)
    least_items = OrderItem.objects.filter(
        order__in=orders
    ).values('menu_item__name').annotate(
        total_quantity=Sum('quantity'),
        total_revenue=Sum('total_price')
    ).order_by('total_quantity')[:5]
    context['least_items'] = least_items
    
    # Payment method breakdown
    payment_breakdown = orders.values('payment_method').annotate(
        count=Count('id'),
        total=Sum('total_amount')
    ).order_by('-total')
    context['payment_breakdown'] = payment_breakdown
    
    # Category performance - show all time if no recent data
    category_performance = OrderItem.objects.filter(
        order__in=orders
    ).values('menu_item__category__category_title').annotate(
        total_quantity=Sum('quantity'),
        total_revenue=Sum('total_price')
    ).exclude(menu_item__category__category_title__isnull=True).order_by('-total_revenue')
    
    # If no categories in date range, get all-time categories
    if not category_performance.exists():
        category_performance = OrderItem.objects.values('menu_item__category__category_title').annotate(
            total_quantity=Sum('quantity'),
            total_revenue=Sum('total_price')
        ).exclude(menu_item__category__category_title__isnull=True).order_by('-total_revenue')
    
    context['category_performance'] = category_performance
    
    # Hourly sales distribution (for staffing optimization)
    hourly_sales = orders.extra(
        select={'hour': "EXTRACT(hour FROM order_date)"}
    ).values('hour').annotate(
        count=Count('id'),
        revenue=Sum('total_amount')
    ).order_by('hour')
    context['hourly_sales'] = hourly_sales
    
    # Customer type breakdown (Regular vs PWD vs Senior)
    customer_breakdown = orders.values('customer__customer_type').annotate(
        count=Count('id'),
        total=Sum('total_amount'),
        discount_total=Sum('discount_amount')
    )
    context['customer_breakdown'] = customer_breakdown
    
    return render(request, 'orders/sales_dashboard.html', context)

def generate_daily_report(request):
    """Generate and save daily sales report for accurate tracking"""
    # Default to TODAY if no date specified
    report_date = request.GET.get('date')
    if report_date:
        report_date = datetime.strptime(report_date, '%Y-%m-%d').date()
    else:
        report_date = date.today()
    
    # Get or create daily sales record
    daily_sales, created = DailySales.objects.get_or_create(date=report_date)
    
    # Get ALL orders for the date - don't filter by status to show ALL activity
    orders = Order.objects.filter(
        order_date__date=report_date
    )
    
    # Update all metrics
    daily_sales.total_orders = orders.count()
    daily_sales.total_revenue = orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    daily_sales.total_discount = orders.aggregate(Sum('discount_amount'))['discount_amount__sum'] or 0
    daily_sales.total_tax = orders.aggregate(Sum('tax_amount'))['tax_amount__sum'] or 0
    
    # Payment method breakdown
    daily_sales.cash_sales = orders.filter(
        payment_method='cash'
    ).aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    
    daily_sales.card_sales = orders.filter(
        payment_method='card'
    ).aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    
    daily_sales.digital_sales = orders.filter(
        payment_method__in=['gcash', 'maya']
    ).aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    
    # Best selling item
    best_item = OrderItem.objects.filter(
        order__in=orders
    ).values('menu_item__name').annotate(
        total=Sum('quantity')
    ).order_by('-total').first()
    
    if best_item:
        daily_sales.best_selling_item = best_item['menu_item__name']
    
    daily_sales.save()
    
    # Additional detailed statistics
    context = {
        'daily_sales': daily_sales,
        'orders': orders.order_by('-order_date'),
        'report_date': report_date,
    }
    
    # Top items for the day
    top_items = OrderItem.objects.filter(
        order__in=orders
    ).values('menu_item__name').annotate(
        total_quantity=Sum('quantity'),
        total_revenue=Sum('total_price')
    ).order_by('-total_revenue')[:5]
    context['top_items'] = top_items
    
    # Payment methods breakdown
    payment_methods = orders.values('payment_method').annotate(
        count=Count('id'),
        total=Sum('total_amount')
    ).order_by('-total')
    context['payment_methods'] = payment_methods
    
    # Hourly breakdown
    hourly_data = []
    for hour in range(24):
        hour_orders = orders.filter(order_date__hour=hour)
        if hour_orders.exists():
            hourly_data.append({
                'hour': f"{hour:02d}:00",
                'orders': hour_orders.count(),
                'revenue': hour_orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
            })
    context['hourly_data'] = hourly_data
    
    # Category breakdown
    category_data = OrderItem.objects.filter(
        order__in=orders
    ).values('menu_item__category__category_title').annotate(
        quantity=Sum('quantity'),
        revenue=Sum('total_price')
    ).order_by('-revenue')
    context['category_data'] = category_data
    
    # Generate PDF if requested
    if request.GET.get('format') == 'pdf':
        return generate_pdf_report(daily_sales, orders, hourly_data, category_data)
    
    return render(request, 'orders/daily_report.html', context)

def generate_pdf_report(daily_sales, orders, hourly_data, category_data):
    """Generate comprehensive PDF sales report"""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []
    styles = getSampleStyleSheet()
    
    # Title
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=colors.HexColor('#2c3e50'),
        alignment=1  # Center
    )
    elements.append(Paragraph("Kwan's Restaurant", title_style))
    elements.append(Spacer(1, 0.2*inch))
    
    # Report header
    header_style = ParagraphStyle(
        'Header',
        parent=styles['Heading2'],
        fontSize=18,
        textColor=colors.HexColor('#34495e')
    )
    elements.append(Paragraph(f"Daily Sales Report - {daily_sales.date}", header_style))
    elements.append(Spacer(1, 0.3*inch))
    
    # Summary table
    summary_data = [
        ['Metric', 'Value'],
        ['Total Orders', str(daily_sales.total_orders)],
        ['Total Revenue', f'PHP {daily_sales.total_revenue:,.2f}'],
        ['Total Discount', f'PHP {daily_sales.total_discount:,.2f}'],
        ['Total Tax', f'PHP {daily_sales.total_tax:,.2f}'],
        ['Cash Sales', f'PHP {daily_sales.cash_sales:,.2f}'],
        ['Card Sales', f'PHP {daily_sales.card_sales:,.2f}'],
        ['Digital Sales', f'PHP {daily_sales.digital_sales:,.2f}'],
        ['Best Selling Item', daily_sales.best_selling_item or 'N/A']
    ]
    
    summary_table = Table(summary_data, colWidths=[3*inch, 2*inch])
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#3498db')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
    ]))
    elements.append(summary_table)
    elements.append(Spacer(1, 0.3*inch))
    
    # Hourly breakdown
    if hourly_data:
        elements.append(Paragraph("Hourly Sales Breakdown", header_style))
        elements.append(Spacer(1, 0.2*inch))
        
        hourly_table_data = [['Hour', 'Orders', 'Revenue']]
        for hour in hourly_data:
            hourly_table_data.append([
                hour['hour'],
                str(hour['orders']),
                f"PHP {hour['revenue']:,.2f}"
            ])
        
        hourly_table = Table(hourly_table_data, colWidths=[1.5*inch, 1.5*inch, 2*inch])
        hourly_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e74c3c')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BACKGROUND', (0, 1), (-1, -1), colors.lightgrey),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        elements.append(hourly_table)
    
    # Build PDF
    doc.build(elements)
    buffer.seek(0)
    
    response = HttpResponse(buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="daily_report_{daily_sales.date}.pdf"'
    return response

def sales_comparison(request):
    """Compare sales across different periods"""
    period1_start = request.GET.get('period1_start')
    period1_end = request.GET.get('period1_end')
    period2_start = request.GET.get('period2_start')
    period2_end = request.GET.get('period2_end')
    
    if not all([period1_start, period1_end, period2_start, period2_end]):
        # Default to this week vs last week
        today = date.today()
        week_start = today - timedelta(days=today.weekday())
        
        period1_start = week_start
        period1_end = today
        period2_start = week_start - timedelta(days=7)
        period2_end = week_start - timedelta(days=1)
    else:
        period1_start = datetime.strptime(period1_start, '%Y-%m-%d').date()
        period1_end = datetime.strptime(period1_end, '%Y-%m-%d').date()
        period2_start = datetime.strptime(period2_start, '%Y-%m-%d').date()
        period2_end = datetime.strptime(period2_end, '%Y-%m-%d').date()
    
    # Get data for both periods
    period1_orders = Order.objects.filter(
        order_date__date__range=[period1_start, period1_end],
        status__in=['completed', 'served']
    )
    
    period2_orders = Order.objects.filter(
        order_date__date__range=[period2_start, period2_end],
        status__in=['completed', 'served']
    )
    
    # Period 1 data
    period1_revenue = period1_orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    period1_count = period1_orders.count()
    period1_avg = period1_orders.aggregate(Avg('total_amount'))['total_amount__avg'] or 0
    period1_customers = period1_orders.values('customer').distinct().count()
    
    # Period 2 data
    period2_revenue = period2_orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    period2_count = period2_orders.count()
    period2_avg = period2_orders.aggregate(Avg('total_amount'))['total_amount__avg'] or 0
    period2_customers = period2_orders.values('customer').distinct().count()
    
    # Calculate growth rates (Period 2 vs Period 1)
    revenue_growth = ((period2_revenue - period1_revenue) / period1_revenue * 100) if period1_revenue > 0 else 0
    orders_growth = ((period2_count - period1_count) / period1_count * 100) if period1_count > 0 else 0
    avg_order_growth = ((period2_avg - period1_avg) / period1_avg * 100) if period1_avg > 0 else 0
    customers_growth = ((period2_customers - period1_customers) / period1_customers * 100) if period1_customers > 0 else 0
    
    context = {
        'period1_start': period1_start,
        'period1_end': period1_end,
        'period1_revenue': period1_revenue,
        'period1_orders': period1_count,
        'period1_avg_order': period1_avg,
        'period1_customers': period1_customers,
        'period2_start': period2_start,
        'period2_end': period2_end,
        'period2_revenue': period2_revenue,
        'period2_orders': period2_count,
        'period2_avg_order': period2_avg,
        'period2_customers': period2_customers,
        'revenue_growth': revenue_growth,
        'orders_growth': orders_growth,
        'avg_order_growth': avg_order_growth,
        'customers_growth': customers_growth
    }
    
    return render(request, 'orders/sales_comparison.html', context)

def export_sales_data(request):
    """Export sales data to Excel"""
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    
    if not start_date:
        start_date = date.today() - timedelta(days=30)
    else:
        start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
    
    if not end_date:
        end_date = date.today()
    else:
        end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
    
    # Get orders
    orders = Order.objects.filter(
        order_date__date__range=[start_date, end_date]
    ).select_related('customer', 'cashier')
    
    # Prepare data for export
    data = []
    for order in orders:
        data.append({
            'Order Number': order.order_number,
            'Date': order.order_date.strftime('%Y-%m-%d %H:%M'),
            'Customer': str(order.customer) if order.customer else 'Walk-in',
            'Table': order.table_number or '',
            'Subtotal': float(order.subtotal),
            'Discount': float(order.discount_amount),
            'Tax': float(order.tax_amount),
            'Total': float(order.total_amount),
            'Payment Method': order.get_payment_method_display(),
            'Status': order.get_status_display(),
            'Cashier': order.cashier.user.get_full_name() if order.cashier else ''
        })
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Create Excel file
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Orders', index=False)
        
        # Add summary sheet
        summary_data = {
            'Metric': ['Total Orders', 'Total Revenue', 'Average Order Value', 'Total Discounts', 'Total Tax'],
            'Value': [
                len(orders),
                df['Total'].sum(),
                df['Total'].mean(),
                df['Discount'].sum(),
                df['Tax'].sum()
            ]
        }
        summary_df = pd.DataFrame(summary_data)
        summary_df.to_excel(writer, sheet_name='Summary', index=False)
    
    buffer.seek(0)
    
    response = HttpResponse(
        buffer.getvalue(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = f'attachment; filename="sales_report_{start_date}_to_{end_date}.xlsx"'
    return response

def real_time_sales_api(request):
    """API endpoint for real-time sales data"""
    today = date.today()
    current_hour = timezone.now().hour
    
    # Get current hour's data
    current_hour_orders = Order.objects.filter(
        order_date__date=today,
        order_date__hour=current_hour
    )
    
    # Get last hour's data for comparison
    last_hour = current_hour - 1 if current_hour > 0 else 23
    last_hour_date = today if current_hour > 0 else today - timedelta(days=1)
    last_hour_orders = Order.objects.filter(
        order_date__date=last_hour_date,
        order_date__hour=last_hour
    )
    
    data = {
        'current_hour': {
            'orders': current_hour_orders.count(),
            'revenue': float(current_hour_orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0)
        },
        'last_hour': {
            'orders': last_hour_orders.count(),
            'revenue': float(last_hour_orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0)
        },
        'today_total': {
            'orders': Order.objects.filter(order_date__date=today).count(),
            'revenue': float(Order.objects.filter(order_date__date=today).aggregate(Sum('total_amount'))['total_amount__sum'] or 0)
        }
    }
    
    return JsonResponse(data)
