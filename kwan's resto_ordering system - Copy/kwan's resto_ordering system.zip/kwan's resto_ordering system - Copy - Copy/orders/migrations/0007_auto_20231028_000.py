from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [
        ('orders', '0006_customer_order'),
    ]

    operations = [
        migrations.AddField(
            model_name='userorder',
            name='status',
            field=models.CharField(
                choices=[
                    ('pending', 'Pending'),
                    ('confirmed', 'Confirmed'),
                    ('preparing', 'Preparing'),
                    ('ready', 'Ready for Pickup'),
                    ('completed', 'Completed')
                ],
                default='pending',
                max_length=20
            ),
        ),
    ]