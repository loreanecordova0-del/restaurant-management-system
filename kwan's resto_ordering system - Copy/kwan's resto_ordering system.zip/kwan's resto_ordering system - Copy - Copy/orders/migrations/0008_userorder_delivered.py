from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [
        ('orders', '0007_auto_20231028_000'),
    ]

    operations = [
        migrations.AddField(
            model_name='userorder',
            name='delivered',
            field=models.BooleanField(default=False),
        ),
    ]