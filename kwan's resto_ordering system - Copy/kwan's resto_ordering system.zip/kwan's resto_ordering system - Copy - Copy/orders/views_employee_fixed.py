# Employee Management Views - QR Code Time Tracking
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.http import JsonResponse, HttpResponse
from django.db.models import Sum, Count, Q
from django.utils import timezone
from django.views.decorators.http import require_POST
from django.contrib import messages
from datetime import datetime, timedelta, date
import json
import random
import string
from io import BytesIO
import qrcode

from .models import Employee, TimeLog, Order

def is_manager(user):
    """Check if user is manager or superuser"""
    if user.is_superuser:
        return True
    if hasattr(user, 'employee_profile'):
        return user.employee_profile.role in ['manager', 'admin']
    return False

@login_required
@user_passes_test(is_manager)
def employee_management(request):
    """Employee management dashboard with QR code time tracking"""
    employees = Employee.objects.all().select_related('user')
    
    # Get current clock-in status for each employee
    for employee in employees:
        employee.is_clocked_in = TimeLog.objects.filter(
            employee=employee,
            clock_out__isnull=True
        ).exists()
    
    # Calculate statistics
    total_employees_count = employees.count()
    active_employees_count = employees.filter(is_active=True).count()
    
    # Currently clocked in
    clocked_in = TimeLog.objects.filter(clock_out__isnull=True)
    clocked_in_count = clocked_in.count()
    
    # Calculate today's total hours
    today = timezone.now().date()
    today_logs = TimeLog.objects.filter(clock_in__date=today)
    total_hours_today = sum([log.hours_worked or 0 for log in today_logs])
    
    # This week's hours
    week_start = today - timedelta(days=today.weekday())
    week_logs = TimeLog.objects.filter(clock_in__date__gte=week_start)
    total_hours_week = sum([log.hours_worked or 0 for log in week_logs])
    
    # Recent time logs with employee info
    recent_time_logs = TimeLog.objects.select_related('employee__user').order_by('-clock_in')[:10]
    
    # On break count (placeholder - you can implement break tracking)
    on_break_count = 0
    
    context = {
        'employees': employees,
        'total_employees_count': total_employees_count,
        'active_employees_count': clocked_in_count,
        'on_break_count': on_break_count,
        'total_hours_today': total_hours_today,
        'total_hours_week': total_hours_week,
        'recent_time_logs': recent_time_logs
    }
    return render(request, 'orders/employee_management.html', context)

@login_required
def employee_time_clock(request):
    """Handle employee time clock in/out"""
    if request.method == 'POST':
        action = request.POST.get('action')
        employee_id = request.POST.get('employee_id')
        
        try:
            employee = Employee.objects.get(employee_id=employee_id)
            
            if action == 'clock_in':
                # Check if already clocked in
                existing = TimeLog.objects.filter(
                    employee=employee,
                    clock_out__isnull=True
                )
                if existing.exists():
                    messages.warning(request, 'Already clocked in!')
                else:
                    TimeLog.objects.create(
                        employee=employee,
                        clock_in=timezone.now()
                    )
                    messages.success(request, f'{employee.user.get_full_name()} clocked in successfully!')
            
            elif action == 'clock_out':
                time_log = TimeLog.objects.filter(
                    employee=employee,
                    clock_out__isnull=True
                ).first()
                
                if time_log:
                    time_log.clock_out = timezone.now()
                    duration = time_log.clock_out - time_log.clock_in
                    time_log.hours_worked = duration.total_seconds() / 3600
                    time_log.save()
                    messages.success(request, f'{employee.user.get_full_name()} clocked out successfully!')
                else:
                    messages.warning(request, 'Not clocked in!')
                    
        except Employee.DoesNotExist:
            messages.error(request, 'Invalid employee ID!')
    
    return redirect('orders:employee_management')

@login_required
def qr_scan_clock(request):
    """QR code scanner for time clock"""
    if request.method == 'POST':
        data = json.loads(request.body)
        employee_id = data.get('employee_id')
        action = data.get('action')
        
        try:
            employee = Employee.objects.get(employee_id=employee_id)
            
            if action == 'clock_in':
                existing = TimeLog.objects.filter(
                    employee=employee,
                    clock_out__isnull=True
                )
                if existing.exists():
                    return JsonResponse({
                        'success': False,
                        'error': 'Already clocked in'
                    })
                
                TimeLog.objects.create(
                    employee=employee,
                    clock_in=timezone.now()
                )
                
                return JsonResponse({
                    'success': True,
                    'message': f'{employee.user.get_full_name()} clocked in'
                })
                
            elif action == 'clock_out':
                time_log = TimeLog.objects.filter(
                    employee=employee,
                    clock_out__isnull=True
                ).first()
                
                if not time_log:
                    return JsonResponse({
                        'success': False,
                        'error': 'Not clocked in'
                    })
                
                time_log.clock_out = timezone.now()
                duration = time_log.clock_out - time_log.clock_in
                time_log.hours_worked = duration.total_seconds() / 3600
                time_log.save()
                
                return JsonResponse({
                    'success': True,
                    'message': f'{employee.user.get_full_name()} clocked out',
                    'hours': time_log.hours_worked
                })
                
        except Employee.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Employee not found'}, status=404)
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=400)
    
    return render(request, 'orders/qr_scan.html')

@login_required
@user_passes_test(is_manager)
def add_employee(request):
    """Add new employee"""
    if request.method == 'POST':
        # Create user
        user = User.objects.create_user(
            username=request.POST.get('username'),
            password=request.POST.get('password'),
            first_name=request.POST.get('first_name'),
            last_name=request.POST.get('last_name'),
            email=request.POST.get('email', '')
        )
        
        # Generate unique employee ID
        employee_id = 'EMP' + ''.join(random.choices(string.digits, k=6))
        while Employee.objects.filter(employee_id=employee_id).exists():
            employee_id = 'EMP' + ''.join(random.choices(string.digits, k=6))
        
        # Create employee profile
        employee = Employee.objects.create(
            user=user,
            employee_id=employee_id,
            role=request.POST.get('role'),
            phone=request.POST.get('phone'),
            address=request.POST.get('address', ''),
            hourly_rate=request.POST.get('hourly_rate', 0)
        )
        
        messages.success(request, f'Employee {employee.user.get_full_name()} added successfully!')
        return redirect('orders:employee_detail', employee_id=employee.id)
    
    return render(request, 'orders/add_employee.html')

@login_required
def employee_detail(request, employee_id):
    """View employee details and performance"""
    employee = get_object_or_404(Employee, id=employee_id)
    
    # Get time logs for this employee
    time_logs = TimeLog.objects.filter(employee=employee).order_by('-clock_in')[:30]
    
    # Calculate performance metrics
    today = date.today()
    week_start = today - timedelta(days=today.weekday())
    month_start = today.replace(day=1)
    
    # This week's hours
    week_logs = TimeLog.objects.filter(
        employee=employee,
        clock_in__date__gte=week_start
    )
    total_hours_week = 0
    earnings_week = 0
    for log in week_logs:
        if log.hours_worked:
            total_hours_week += log.hours_worked
            earnings_week += log.hours_worked * float(employee.hourly_rate)
    
    # This month's days worked
    month_logs = TimeLog.objects.filter(
        employee=employee,
        clock_in__date__gte=month_start
    )
    days_worked_month = month_logs.values('clock_in__date').distinct().count()
    
    # Add calculated fields to time logs
    for log in time_logs:
        if log.hours_worked:
            log.earnings = log.hours_worked * float(employee.hourly_rate)
    
    context = {
        'employee': employee,
        'time_logs': time_logs,
        'total_hours_week': total_hours_week,
        'earnings_week': earnings_week,
        'days_worked_month': days_worked_month,
        'is_clocked_in': TimeLog.objects.filter(
            employee=employee,
            clock_out__isnull=True
        ).exists()
    }
    return render(request, 'orders/employee_detail.html', context)

@login_required
@user_passes_test(is_manager)
def generate_qr_code(request, employee_id):
    """Generate and download QR code for employee"""
    employee = get_object_or_404(Employee, id=employee_id)
    
    # Generate QR code
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(employee.employee_id)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Save to BytesIO
    buffer = BytesIO()
    img.save(buffer, format='PNG')
    buffer.seek(0)
    
    # Return as download
    response = HttpResponse(buffer, content_type='image/png')
    response['Content-Disposition'] = f'attachment; filename="{employee.employee_id}_qr.png"'
    return response

@login_required
@user_passes_test(is_manager)
def toggle_employee_status(request, employee_id):
    """Toggle employee active status"""
    employee = get_object_or_404(Employee, id=employee_id)
    employee.is_active = not employee.is_active
    employee.save()
    
    status = 'activated' if employee.is_active else 'deactivated'
    messages.success(request, f'Employee {employee.user.get_full_name()} {status}!')
    
    return redirect('orders:employee_detail', employee_id=employee.id)

@login_required
@user_passes_test(is_manager)
def employee_time_report(request):
    """Generate employee time report"""
    # Date range
    start_date = request.GET.get('start_date', (timezone.now() - timedelta(days=7)).date())
    end_date = request.GET.get('end_date', timezone.now().date())
    
    # Get all time logs in range
    time_logs = TimeLog.objects.filter(
        clock_in__date__range=[start_date, end_date]
    ).select_related('employee__user').order_by('employee', '-clock_in')
    
    # Group by employee
    employee_data = {}
    for log in time_logs:
        emp_id = log.employee.id
        if emp_id not in employee_data:
            employee_data[emp_id] = {
                'employee': log.employee,
                'logs': [],
                'total_hours': 0,
                'total_earnings': 0
            }
        
        employee_data[emp_id]['logs'].append(log)
        if log.hours_worked:
            employee_data[emp_id]['total_hours'] += log.hours_worked
            employee_data[emp_id]['total_earnings'] += log.hours_worked * float(log.employee.hourly_rate)
    
    context = {
        'start_date': start_date,
        'end_date': end_date,
        'employee_data': employee_data.values(),
        'total_hours': sum(d['total_hours'] for d in employee_data.values()),
        'total_earnings': sum(d['total_earnings'] for d in employee_data.values())
    }
    
    return render(request, 'orders/employee_time_report.html', context)
