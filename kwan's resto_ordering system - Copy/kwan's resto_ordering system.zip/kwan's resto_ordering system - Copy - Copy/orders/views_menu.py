# Menu Management Views
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.db.models import Count, Avg, Sum
from decimal import Decimal
import json

from .models import Category, MenuItem, OrderItem

def is_manager(user):
    """Check if user is manager"""
    if hasattr(user, 'employee_profile'):
        return user.employee_profile.role in ['manager', 'admin']
    return False

@login_required
@user_passes_test(is_manager)
def menu_management(request):
    """Menu management interface"""
    categories = Category.objects.all().prefetch_related('menu_items')
    
    # Statistics
    total_items = MenuItem.objects.count()
    active_items = MenuItem.objects.filter(is_available=True).count()
    inactive_items = total_items - active_items
    total_categories = categories.count()
    
    # Popular items (based on orders)
    popular_items = MenuItem.objects.annotate(
        order_count=Count('orderitem')
    ).order_by('-order_count')[:5]
    
    context = {
        'categories': categories,
        'total_items': total_items,
        'active_items': active_items,
        'inactive_items': inactive_items,
        'total_categories': total_categories,
        'popular_items': popular_items
    }
    return render(request, 'orders/menu_management.html', context)

@login_required
@user_passes_test(is_manager)
def add_category(request):
    """Add new category"""
    if request.method == 'POST':
        category = Category.objects.create(
            category_title=request.POST.get('category_title'),
            category_description=request.POST.get('category_description'),
            display_order=int(request.POST.get('display_order', 0)),
            is_active=request.POST.get('is_active') == 'on'
        )
        
        # Handle image upload
        if 'category_image' in request.FILES:
            category.category_image = request.FILES['category_image']
            category.save()
        
        messages.success(request, f'Category "{category.category_title}" added successfully!')
        return redirect('orders:menu_management')
    
    return render(request, 'orders/add_category.html')

@login_required
@user_passes_test(is_manager)
def edit_category(request, category_id):
    """Edit category"""
    category = get_object_or_404(Category, id=category_id)
    
    if request.method == 'POST':
        category.category_title = request.POST.get('category_title')
        category.category_description = request.POST.get('category_description')
        category.display_order = int(request.POST.get('display_order', 0))
        category.is_active = request.POST.get('is_active') == 'on'
        
        if 'category_image' in request.FILES:
            category.category_image = request.FILES['category_image']
        
        category.save()
        messages.success(request, 'Category updated successfully!')
        return redirect('orders:menu_management')
    
    return render(request, 'orders/edit_category.html', {'category': category})

@login_required
@user_passes_test(is_manager)
def add_menu_item(request):
    """Add new menu item"""
    if request.method == 'POST':
        # Create menu item
        menu_item = MenuItem.objects.create(
            name=request.POST.get('name'),
            category_id=request.POST.get('category_id'),
            description=request.POST.get('description'),
            base_price=Decimal(request.POST.get('base_price')),
            preparation_time=int(request.POST.get('preparation_time', 15)),
            is_available=request.POST.get('is_available') == 'on',
            is_vegetarian=request.POST.get('is_vegetarian') == 'on',
            is_spicy=request.POST.get('is_spicy') == 'on',
            allergens=request.POST.get('allergens', ''),
            calories=int(request.POST.get('calories')) if request.POST.get('calories') else None
        )
        
        # Handle sizes and pricing
        sizes = {}
        if request.POST.get('has_sizes') == 'on':
            if request.POST.get('small_price'):
                sizes['small'] = float(request.POST.get('small_price'))
            if request.POST.get('medium_price'):
                sizes['medium'] = float(request.POST.get('medium_price'))
            if request.POST.get('large_price'):
                sizes['large'] = float(request.POST.get('large_price'))
        
        if sizes:
            menu_item.sizes_available = sizes
        else:
            menu_item.sizes_available = {'regular': float(menu_item.base_price)}
        
        # Handle image upload
        if 'image' in request.FILES:
            menu_item.image = request.FILES['image']
        
        menu_item.save()
        
        messages.success(request, f'Menu item "{menu_item.name}" added successfully!')
        return redirect('orders:menu_management')
    
    categories = Category.objects.filter(is_active=True)
    return render(request, 'orders/add_menu_item.html', {'categories': categories})

@login_required
@user_passes_test(is_manager)
def edit_menu_item(request, item_id):
    """Edit menu item"""
    menu_item = get_object_or_404(MenuItem, id=item_id)
    
    if request.method == 'POST':
        menu_item.name = request.POST.get('name')
        menu_item.category_id = request.POST.get('category_id')
        menu_item.description = request.POST.get('description')
        menu_item.base_price = Decimal(request.POST.get('base_price'))
        menu_item.preparation_time = int(request.POST.get('preparation_time', 15))
        menu_item.is_available = request.POST.get('is_available') == 'on'
        menu_item.is_vegetarian = request.POST.get('is_vegetarian') == 'on'
        menu_item.is_spicy = request.POST.get('is_spicy') == 'on'
        menu_item.allergens = request.POST.get('allergens', '')
        menu_item.calories = int(request.POST.get('calories')) if request.POST.get('calories') else None
        
        # Update sizes
        sizes = {}
        if request.POST.get('has_sizes') == 'on':
            if request.POST.get('small_price'):
                sizes['small'] = float(request.POST.get('small_price'))
            if request.POST.get('medium_price'):
                sizes['medium'] = float(request.POST.get('medium_price'))
            if request.POST.get('large_price'):
                sizes['large'] = float(request.POST.get('large_price'))
        
        if sizes:
            menu_item.sizes_available = sizes
        else:
            menu_item.sizes_available = {'regular': float(menu_item.base_price)}
        
        # Handle image upload
        if 'image' in request.FILES:
            menu_item.image = request.FILES['image']
        
        menu_item.save()
        
        messages.success(request, 'Menu item updated successfully!')
        return redirect('orders:menu_item_detail', item_id=menu_item.id)
    
    categories = Category.objects.filter(is_active=True)
    return render(request, 'orders/edit_menu_item.html', {
        'menu_item': menu_item,
        'categories': categories
    })

@login_required
def menu_item_detail(request, item_id):
    """View menu item details"""
    menu_item = get_object_or_404(MenuItem, id=item_id)
    
    # Get sales statistics
    order_items = OrderItem.objects.filter(menu_item=menu_item)
    total_sold = order_items.aggregate(Sum('quantity'))['quantity__sum'] or 0
    total_revenue = order_items.aggregate(Sum('total_price'))['total_price__sum'] or 0
    
    # Get recent orders
    recent_orders = order_items.select_related('order').order_by('-order__order_date')[:10]
    
    context = {
        'menu_item': menu_item,
        'total_sold': total_sold,
        'total_revenue': total_revenue,
        'recent_orders': recent_orders
    }
    return render(request, 'orders/menu_item_detail.html', context)

@login_required
@user_passes_test(is_manager)
@require_POST
def toggle_menu_item(request, item_id):
    """Toggle menu item availability via AJAX"""
    try:
        menu_item = get_object_or_404(MenuItem, id=item_id)
        menu_item.is_available = not menu_item.is_available
        menu_item.save()
        
        return JsonResponse({
            'success': True,
            'is_available': menu_item.is_available,
            'message': f'{menu_item.name} is now {"available" if menu_item.is_available else "unavailable"}'
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=400)

@login_required
@user_passes_test(is_manager)
@require_POST
def delete_menu_item(request, item_id):
    """Delete menu item"""
    try:
        menu_item = get_object_or_404(MenuItem, id=item_id)
        
        # Check if item has been ordered
        if OrderItem.objects.filter(menu_item=menu_item).exists():
            # Don't delete, just mark as unavailable
            menu_item.is_available = False
            menu_item.save()
            return JsonResponse({
                'success': True,
                'message': 'Item has order history. Marked as unavailable instead of deleting.'
            })
        else:
            name = menu_item.name
            menu_item.delete()
            return JsonResponse({
                'success': True,
                'message': f'{name} deleted successfully'
            })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=400)

@login_required
def menu_display(request):
    """Public menu display for customers"""
    categories = Category.objects.filter(is_active=True).prefetch_related(
        'menu_items'
    ).order_by('display_order')
    
    # Filter by dietary preferences if specified
    dietary = request.GET.get('dietary')
    if dietary == 'vegetarian':
        for category in categories:
            category.filtered_items = category.menu_items.filter(
                is_available=True, 
                is_vegetarian=True
            )
    else:
        for category in categories:
            category.filtered_items = category.menu_items.filter(is_available=True)
    
    context = {
        'categories': categories,
        'dietary_filter': dietary
    }
    return render(request, 'orders/menu_display.html', context)

@login_required
@user_passes_test(is_manager)
def menu_analytics(request):
    """Menu performance analytics"""
    # Top performing items by revenue
    top_items = MenuItem.objects.annotate(
        total_quantity=Count('orderitem'),
        total_revenue=Sum('orderitem__total_price')
    ).filter(total_quantity__gt=0).order_by('-total_revenue')[:10]
    
    # Least performing items
    least_items = MenuItem.objects.annotate(
        total_quantity=Count('orderitem')
    ).order_by('total_quantity')[:10]
    
    # Category performance
    category_performance = Category.objects.annotate(
        total_items=Count('menu_items'),
        available_items=Count('menu_items', filter=models.Q(menu_items__is_available=True)),
        total_orders=Count('menu_items__orderitem'),
        total_revenue=Sum('menu_items__orderitem__total_price')
    ).order_by('-total_revenue')
    
    # Items never ordered
    never_ordered = MenuItem.objects.annotate(
        order_count=Count('orderitem')
    ).filter(order_count=0)
    
    # Price analysis
    price_ranges = [
        {'range': '₱0-100', 'count': MenuItem.objects.filter(base_price__lt=100).count()},
        {'range': '₱100-200', 'count': MenuItem.objects.filter(base_price__gte=100, base_price__lt=200).count()},
        {'range': '₱200-300', 'count': MenuItem.objects.filter(base_price__gte=200, base_price__lt=300).count()},
        {'range': '₱300-500', 'count': MenuItem.objects.filter(base_price__gte=300, base_price__lt=500).count()},
        {'range': '₱500+', 'count': MenuItem.objects.filter(base_price__gte=500).count()},
    ]
    
    context = {
        'top_items': top_items,
        'least_items': least_items,
        'category_performance': category_performance,
        'never_ordered': never_ordered,
        'never_ordered_count': never_ordered.count(),
        'price_ranges': price_ranges
    }
    
    return render(request, 'orders/menu_analytics.html', context)

@login_required
@user_passes_test(is_manager)
def bulk_update_prices(request):
    """Bulk update menu prices"""
    if request.method == 'POST':
        update_type = request.POST.get('update_type')
        value = Decimal(request.POST.get('value', 0))
        category_id = request.POST.get('category_id')
        
        # Get items to update
        if category_id:
            items = MenuItem.objects.filter(category_id=category_id)
        else:
            items = MenuItem.objects.all()
        
        updated_count = 0
        
        for item in items:
            if update_type == 'percentage':
                # Increase by percentage
                item.base_price = item.base_price * (1 + value / 100)
                
                # Update size prices if they exist
                if item.sizes_available:
                    for size, price in item.sizes_available.items():
                        item.sizes_available[size] = float(Decimal(str(price)) * (1 + value / 100))
            
            elif update_type == 'fixed':
                # Increase by fixed amount
                item.base_price += value
                
                # Update size prices if they exist
                if item.sizes_available:
                    for size, price in item.sizes_available.items():
                        item.sizes_available[size] = float(Decimal(str(price)) + value)
            
            item.save()
            updated_count += 1
        
        messages.success(request, f'Updated prices for {updated_count} items')
        return redirect('orders:menu_management')
    
    categories = Category.objects.all()
    return render(request, 'orders/bulk_update_prices.html', {'categories': categories})
