$(document).ready(function() {
  // initialize AJAX sidebar cart (server session)
  try {
    if (typeof window._loadCart === 'function') {
      window._loadCart();
    } else if (typeof loadCart === 'function') {
      loadCart();
    }
  } catch (e) {
    console.error('init cart load failed', e);
  }

  // on full cart page use the local-storage renderer if present
  if (window.location.href.indexOf("/cart") > -1) {
    if (typeof load_cart === 'function') load_cart();
  }

  if (window.location.href.indexOf("view-orders") > -1){
    order_list_functionality();
  }
});

function order_list_functionality(){
  onRowClick("orders_table", function (row){
    var id = row.getElementsByTagName("td")[0].innerHTML;
    var csrftoken = getCookie('csrftoken');
    //send get request to see if user has superuser permissions
    var user_is_super = check_user_super();
    if ( user_is_super && row.classList.contains("mark-as-complete") ){
      var r = confirm("Would you like to mark order "+id+" as delivered?");
      if (r == true) {
        $.ajax({
            url : "/mark_order_as_delivered" , // the endpoint
            type : "POST", // http method
            data : { id : id, csrfmiddlewaretoken: csrftoken}, // data sent with the post request

            // handle a successful response
            success : function(json) {
                //make the row green
                row.classList.remove("table-danger");
                row.classList.add("table-success")
            },

            // handle a non-successful response
            error : function(xhr,errmsg,err) {
                //have this as another toast
                console.log("the server said no lol")
            }
        }); //make ajax post request
      }
    }

  });
}

function check_user_super(){
  var return_value;
  $.ajax({
       url: "check_superuser",
       type: 'GET',
       success: function(res) {
            console.log("we got back from the server the value ---> "+res)
            if (res == "True"){
              console.log("assigned true")
              return_value = true;
            }else{
              return_value = false;
            }
        },
        async: false
  });
  return return_value
}

function add_to_cart(info){
  //info will be the stuff displayed in the reciept
  // item description as well as teh price
  display_notif("add to cart", info);
  var cart_retrieved = localStorage.getItem("cart")
  if (cart_retrieved === null){
    //make a new cart
    var cart = [info];
    localStorage.setItem('cart', JSON.stringify(cart));
  }else{
    var cart = JSON.parse(cart_retrieved);
    cart.push(info)
    localStorage.setItem('cart', JSON.stringify(cart));
  }


}

function onRowClick(tableId, callback) {
  var table = document.getElementById(tableId),
      rows = table.getElementsByTagName("tr"),
      i;

    for (i = 0; i < rows.length; i++) {
        table.rows[i].onclick = function (row) {return function () {callback(row);};}(table.rows[i]);
    }
}

function display_notif(type, info="No info provided"){
  //the different types of toasts are success, warning ... info and error
  toastr.options = {
    "closeButton": true,
    "debug": false,
    "newestOnTop": false,
    "progressBar": true,
    "positionClass": "toast-top-right",
    "preventDuplicates": false,
    "onclick": null,
    "showDuration": "70",
    "hideDuration": "1000",
    "timeOut": "2000",
    "extendedTimeOut": "500",
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
  }
  switch (type){
    case "add to cart":
      toastr.success(info.item_description + ': £' + info.price, 'Added to Cart');
      break;
    case "remove from cart":
      toastr.warning("Successfully removed "+info+ " from cart");
      break;
    case "new order":
      toastr.success("Order successfully placed");
      break;
  }

}

function load_cart(){
  var table = document.getElementById('cart_body');
  table.innerHTML = ""; //clear the table
  document.getElementById('cart_heading').innerHTML = "To remove an item from cart, simply click it..."
  var cart = JSON.parse(localStorage.getItem("cart"));
  var total = 0;
  if (cart !== null && cart.length > 0){
    for (var i = 0; i < cart.length; i++) {

      var row = table.insertRow(-1);
      var item_number = row.insertCell(0);
      var item_description = row.insertCell(1);
      var item_price = row.insertCell(2);
      item_number.innerHTML = String(i+1);
      item_description.innerHTML = cart[i].item_description;
      item_price.innerHTML = "£"+cart[i].price;

      total += cart[i].price
    }
    total = Math.round(total * 100) / 100
    localStorage.setItem('total_price', total);
    document.getElementById('total').innerHTML = "£"+localStorage.getItem("total_price")


    onRowClick("cart_body", function (row){
      var value = row.getElementsByTagName("td")[0].innerHTML;
      var description = row.getElementsByTagName("td")[1].innerHTML;
      var r = confirm("Proceed to delete '"+description+ "' from cart?");
      if (r == true) {
        document.getElementById("cart_body").deleteRow(value-1);
        //edit the cart
        cart.splice(value-1,1) //this is how you remove elements from a list in javascript
        localStorage.setItem('cart', JSON.stringify(cart)); //change the elements in the cart in local storage
        display_notif("remove from cart", description)
        load_cart() //refresh the page
      }
    });
  }else{
    display_empty_cart()
  }
}

function format_toppings(topping_choices){
  var toppings = ""
  var arrayLength = topping_choices.length;
  for (var i = 0; i < arrayLength; i++) {
      if (i == 0){
        //first iteration
        toppings += topping_choices[i]
      }else{
        toppings += " + "
        toppings += topping_choices[i]
      }
  }
  return toppings
}

function pizza_toppings(number_of_toppings, type_of_pizza, price){
  var last_valid_selection = null;

  $('#toppings_label')[0].innerHTML = "Choose "+ String(number_of_toppings) +" topping(s) here"
  $('#select_toppings').change(function(event) {
    console.log($(this).val().length)
    console.log(number_of_toppings)
    if ($(this).val().length > number_of_toppings) {

      $(this).val(last_valid_selection);
    } else {
      last_valid_selection = $(this).val();
    }
  }); //this is what restircts the user from choosing more than they are paying fpr

  $('#toppings_modal').modal('show'); //show the modal
  $("#submit_toppings").click(function(){
    var topping_choices = $('#select_toppings').val();
    //console.log("TOPping choices are "+topping_choices[0])

    $('#toppings_modal').modal('toggle'); //hide the modal
    var info={
      "item_description": type_of_pizza + " pizza with "+ format_toppings(topping_choices),
      "price":price
    }
    add_to_cart(info)

  });
};

function close_modal(){
  $('#toppings_modal').modal('hide');
  $('#toppings_modal').modal('dispose');
}

(function () {
  function getCookie(name) {
    const m = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)');
    return m ? m.pop() : '';
  }
  const csrftoken = getCookie('csrftoken');

  function fetchJson(url, opts = {}) {
    return fetch(url, Object.assign({ credentials: 'same-origin' }, opts)).then(r => {
      if (!r.ok) throw new Error('Network ' + r.status);
      return r.json();
    });
  }

  function escapeHtml(s){ return s ? String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;') : ''; }

  function renderCartFromObj(cartObj) {
    const cont = document.getElementById('cart-contents');
    if (!cont) return;
    const items = cartObj || {};
    const keys = Object.keys(items);
    if (!keys.length) { cont.innerHTML = '<p class="text-muted">Your cart is empty.</p>'; return; }
    let total = 0;
    let html = '<div class="list-group">';
    keys.forEach(k => {
      const it = items[k];
      if (!it || typeof it !== 'object') return;
      const qty = parseInt(it.quantity || 0,10) || 0;
      const price = parseFloat(it.price || 0) || 0;
      const subtotal = qty * price;
      total += subtotal;
      html += `<div class="list-group-item d-flex justify-content-between">
        <div><strong>${escapeHtml(it.name)}</strong><br><small class="text-muted">${escapeHtml(it.type||'')}</small></div>
        <div class="text-end"><div>${qty} × $${price.toFixed(2)}</div><div class="text-muted">$${subtotal.toFixed(2)}</div></div>
      </div>`;
    });
    html += `</div><div class="mt-3 text-end"><strong>Total: $${total.toFixed(2)}</strong></div>`;
    cont.innerHTML = html;
  }

  function loadCart() {
    fetchJson('/retrieve_saved_cart/', { method: 'GET' })
      .then(resp => { console.log('DEBUG loadCart resp', resp); if (resp && resp.cart) renderCartFromObj(resp.cart); else renderCartFromObj({}); })
      .catch(err => console.error('loadCart error', err));
  }

  function addToCartAjax(id, type, name, price, buttonEl) {
    const fd = new FormData();
    fd.append('type', type);
    fd.append('name', name);
    fd.append('price', price);
    fetchJson(`/add_to_cart/${id}/`, {
      method: 'POST',
      body: fd,
      headers: { 'X-CSRFToken': csrftoken, 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(json => {
      console.log('DEBUG add_to_cart response', json);
      if (json && json.success && json.cart) {
        renderCartFromObj(json.cart);
        if (buttonEl) { const prev = buttonEl.textContent; buttonEl.textContent = 'Added'; setTimeout(()=> buttonEl.textContent = prev, 800); }
      } else {
        loadCart();
      }
    })
    .catch(err => { console.error('add_to_cart error', err); });
  }

  document.addEventListener('click', function (ev) {
    const btn = ev.target.closest && ev.target.closest('.btn-add-to-cart');
    if (!btn) return;
    ev.preventDefault();
    const id = btn.dataset.id;
    const type = btn.dataset.type || 'item';
    const name = btn.dataset.name || `Item ${id}`;
    const price = btn.dataset.price || 0;
    addToCartAjax(id, type, name, price, btn);
  });

  document.addEventListener('DOMContentLoaded', function () { loadCart(); });
  // fallback in case DOM already ready
  setTimeout(loadCart, 300);
  window._loadCart = loadCart;
})();
