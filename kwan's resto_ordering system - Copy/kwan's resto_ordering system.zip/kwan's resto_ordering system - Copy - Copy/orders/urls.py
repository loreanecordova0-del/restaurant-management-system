from django.urls import path
from . import views
from . import views_pos as pos_views
from . import views_customer, views_employee, views_analytics, views_kitchen, views_menu
from .views_pos_simple import create_simple_order
from . import views_analytics_extended

app_name = "orders"

urlpatterns = [
    # Main Views
    path("", views.index, name="index"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    
    # POS System URLs (Problem #1: Accurate Order Recording)
    path('pos/', pos_views.pos_interface, name='pos_interface'),
    path('pos/create-order/', pos_views.create_order, name='create_order'),
    path('pos/create-simple-order/', create_simple_order, name='create_simple_order'),
    path("pos/search-items/", views.search_menu_items, name="search_menu_items"),
    path("pos/receipt/<int:order_id>/", views.generate_receipt, name="generate_receipt"),
    path("pos/void-order/<int:order_id>/", views.void_order, name="void_order"),
    path("quick-order/", views.quick_order, name="quick_order"),
    
    # Employee Management URLs (QR Code Time Tracking)
    path("employee/time-clock/", views_employee.employee_time_clock, name="employee_time_clock"),
    path("employee/management/", views_employee.employee_management, name="employee_management"),
    path("employee/add/", views_employee.add_employee, name="add_employee"),
    path("employee/<int:employee_id>/", views_employee.employee_detail, name="employee_detail"),
    path("employee/<int:employee_id>/toggle/", views_employee.toggle_employee_status, name="toggle_employee_status"),
    path("employee/time-report/", views_employee.employee_time_report, name="employee_time_report"),
    path('employee/update-breaks/', views_employee.update_breaks, name='update_breaks'),
    
    # Sales Analytics URLs (Problem #2: Accurate Sales Tracking)
    path("sales/dashboard/", views_analytics.sales_dashboard, name="sales_dashboard"),
    path("sales/daily-report/", views_analytics.generate_daily_report, name="generate_daily_report"),
    path("sales/comparison/", views_analytics.sales_comparison, name="sales_comparison"),
    path("sales/export/", views_analytics.export_sales_data, name="export_sales_data"),
    
    # Extended Analytics URLs
    path("analytics/customers/", views_analytics_extended.customer_analytics, name="customer_analytics"),
    path("analytics/menu/", views_analytics_extended.menu_analytics, name="menu_analytics"),
    path("sales/real-time/", views_analytics.real_time_sales_api, name="real_time_sales_api"),
    
    # Customer Management URLs (Problem #3: Customer Complaints)
    path("customers/", views_customer.customer_management, name="customer_management"),
    path("customers/add/", views_customer.add_customer, name="add_customer"),
    path("customers/<int:customer_id>/", views_customer.customer_detail, name="customer_detail"),
    path("customers/<int:customer_id>/edit/", views_customer.edit_customer, name="edit_customer"),
    path("customers/<int:customer_id>/loyalty-points/", views_customer.add_loyalty_points, name="add_loyalty_points"),
    path("customers/loyalty/", views_customer.customer_loyalty, name="customer_loyalty"),
    path("customers/analytics/", views_customer.customer_analytics, name="customer_analytics"),
    
    # Feedback Management URLs (Handling Complaints)
    path("feedback/", views_customer.feedback_management, name="feedback_management"),
    path("feedback/add/", views_customer.add_feedback, name="add_feedback"),
    path("feedback/<int:feedback_id>/resolve/", views_customer.resolve_feedback, name="resolve_feedback"),
    path("feedback/<int:feedback_id>/quick-resolve/", views_customer.quick_resolve_feedback, name="quick_resolve_feedback"),
    
    # Kitchen Display System URLs
    path("kitchen/display/", views_kitchen.kitchen_display, name="kitchen_display"),
    path("kitchen/order/<int:order_id>/update/", views_kitchen.update_kitchen_order, name="update_kitchen_order"),
    path("kitchen/order/<int:order_id>/", views_kitchen.kitchen_order_detail, name="kitchen_order_detail"),
    path("kitchen/performance/", views_kitchen.kitchen_performance, name="kitchen_performance"),
    path("kitchen/expeditor/", views_kitchen.expeditor_view, name="expeditor_view"),
    path("kitchen/order/<int:order_id>/served/", views_kitchen.mark_order_served, name="mark_order_served"),
    path("kitchen/alerts/", views_kitchen.kitchen_alerts, name="kitchen_alerts"),
    path("kitchen/recipe/<int:item_id>/", views_kitchen.recipe_view, name="recipe_view"),
    
    # Menu Management URLs
    path("menu/", views.menu_view, name="menu"),
    path("menu/display/", views_menu.menu_display, name="menu_display"),
    path("menu/management/", views_menu.menu_management, name="menu_management"),
    path("menu/category/add/", views_menu.add_category, name="add_category"),
    path("menu/category/<int:category_id>/edit/", views_menu.edit_category, name="edit_category"),
    path("menu/item/add/", views_menu.add_menu_item, name="add_menu_item"),
    path("menu/item/<int:item_id>/edit/", views_menu.edit_menu_item, name="edit_menu_item"),
    path("menu/item/<int:item_id>/", views_menu.menu_item_detail, name="menu_item_detail"),
    path("menu/item/<int:item_id>/toggle/", views_menu.toggle_menu_item, name="toggle_menu_item"),
    path("menu/item/<int:item_id>/delete/", views_menu.delete_menu_item, name="delete_menu_item"),
    path("menu/analytics/", views_menu.menu_analytics, name="menu_analytics"),
    path("menu/bulk-update-prices/", views_menu.bulk_update_prices, name="bulk_update_prices"),
    
    # Order Management URLs
    path("orders/", views.order_list, name="order_list"),
    path("orders/<int:order_id>/", views.order_detail, name="order_detail"),
    path("orders/<int:order_id>/status/", views.update_order_status, name="update_order_status"),
    
    # General URLs
    path("directions/", views.directions, name="directions"),
    path("hours/", views.hours, name="hours"),
    path("contact/", views.contact, name="contact"),
    path("reports/", views.reports, name="reports"),
    path("settings/", views.settings, name="settings"),
]
