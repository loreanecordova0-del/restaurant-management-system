# Kitchen Display System Views - Order Preparation Management
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.utils import timezone
from django.db.models import Q, Count
from datetime import timedelta
import json

from .models import KitchenOrder, Order, OrderItem, Employee

@login_required
def kitchen_display(request):
    """Real-time kitchen display system for order preparation"""
    now = timezone.now()
    
    # Get all orders for kitchen display
    pending_orders = Order.objects.filter(status='pending').order_by('order_date').prefetch_related('items')
    preparing_orders = Order.objects.filter(status='preparing').order_by('order_date').prefetch_related('items')
    ready_orders = Order.objects.filter(status='ready').order_by('order_date').prefetch_related('items')
    
    # Add time calculations
    for order in pending_orders:
        order.minutes_waiting = int((now - order.order_date).total_seconds() / 60)
    
    for order in preparing_orders:
        order.minutes_preparing = int((now - order.order_date).total_seconds() / 60)
        order.prep_start_time = order.order_date
    
    for order in ready_orders:
        order.minutes_ready = int((now - order.order_date).total_seconds() / 60)
        order.ready_time = order.order_date
    
    # Calculate average prep time
    avg_prep_time = 15  # Default 15 minutes
    
    context = {
        'pending_orders': pending_orders,
        'preparing_orders': preparing_orders,
        'ready_orders': ready_orders,
        'pending_count': pending_orders.count(),
        'preparing_count': preparing_orders.count(),
        'ready_count': ready_orders.count(),
        'avg_prep_time': avg_prep_time,
        'current_time': now
    }
    return render(request, 'orders/kitchen_display.html', context)

@login_required
@require_POST
def update_kitchen_order(request, order_id):
    """Update the status of a kitchen order"""
    try:
        data = json.loads(request.body)
        status = data.get('status')
        
        order = Order.objects.get(id=order_id)
        order.status = status
        order.updated_at = timezone.now()
        order.save()
        
        return JsonResponse({'success': True})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

@login_required
def kitchen_order_detail(request, order_id):
    """View details of a specific kitchen order"""
    order = get_object_or_404(Order, id=order_id)
    context = {
        'order': order,
        'items': order.items.all()
    }
    return render(request, 'orders/kitchen_order_detail.html', context)

@login_required
def kitchen_performance(request):
    """Kitchen performance metrics"""
    today = timezone.now().date()
    
    # Get performance metrics
    total_orders_today = Order.objects.filter(order_date__date=today).count()
    completed_orders = Order.objects.filter(
        status='completed',
        order_date__date=today
    ).count()
    
    pending_orders = Order.objects.filter(status='pending').count()
    
    context = {
        'total_orders_today': total_orders_today,
        'completed_orders': completed_orders,
        'pending_orders': pending_orders,
        'completion_rate': (completed_orders / total_orders_today * 100) if total_orders_today > 0 else 0
    }
    return render(request, 'orders/kitchen_performance.html', context)

@login_required
def expeditor_view(request):
    """Expeditor view for coordinating orders"""
    ready_orders = Order.objects.filter(status='ready').order_by('order_date')
    
    context = {
        'ready_orders': ready_orders,
        'ready_count': ready_orders.count()
    }
    return render(request, 'orders/expeditor.html', context)

@login_required
@require_POST
def mark_order_served(request, order_id):
    """Mark an order as served"""
    order = get_object_or_404(Order, id=order_id)
    order.status = 'served'
    order.served_at = timezone.now()
    order.save()
    
    return redirect('orders:expeditor_view')

@login_required
def kitchen_alerts(request):
    """Display kitchen alerts for urgent orders"""
    # Orders waiting more than 20 minutes
    urgent_orders = []
    pending_orders = Order.objects.filter(status='pending')
    
    for order in pending_orders:
        wait_time = (timezone.now() - order.order_date).total_seconds() / 60
        if wait_time > 20:
            order.wait_time = int(wait_time)
            urgent_orders.append(order)
    
    context = {
        'urgent_orders': urgent_orders
    }
    return render(request, 'orders/kitchen_alerts.html', context)

@login_required
def recipe_view(request, item_id):
    """Display recipe for a menu item"""
    from .models import MenuItem
    
    item = get_object_or_404(MenuItem, id=item_id)
    context = {
        'item': item
    }
    return render(request, 'orders/recipe.html', context)
