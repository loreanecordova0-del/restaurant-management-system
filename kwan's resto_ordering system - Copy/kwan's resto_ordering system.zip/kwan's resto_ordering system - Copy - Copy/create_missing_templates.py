import os

# Base directory
BASE_DIR = r"c:\Users\Admin\Desktop\kwan's resto_ordering system\orders\templates\orders"

# Template list with their basic content
templates = {
    "pos_interface.html": """{% extends "base.html" %}
{% block title %}POS System - Kwan's Restaurant{% endblock %}
{% block content %}
<div class="container-fluid mt-4">
  <h1>POS System</h1>
  <p class="text-muted">Point of Sale interface coming soon...</p>
  <a href="{% url 'orders:dashboard' %}" class="btn btn-secondary">Back to Dashboard</a>
</div>
{% endblock %}""",

    "employee_time_clock.html": """{% extends "base.html" %}
{% block title %}Time Clock - Kwan's Restaurant{% endblock %}
{% block content %}
<div class="container mt-4">
  <h1>Employee Time Clock</h1>
  <p class="text-muted">QR-based time tracking interface coming soon...</p>
  <a href="{% url 'orders:dashboard' %}" class="btn btn-secondary">Back to Dashboard</a>
</div>
{% endblock %}""",

    "employee_management.html": """{% extends "base.html" %}
{% block title %}Employee Management - Kwan's Restaurant{% endblock %}
{% block content %}
<div class="container-fluid mt-4">
  <h1>Employee Management</h1>
  <p class="text-muted">Employee management interface coming soon...</p>
  <a href="{% url 'orders:dashboard' %}" class="btn btn-secondary">Back to Dashboard</a>
</div>
{% endblock %}""",

    "kitchen_display.html": """{% extends "base.html" %}
{% block title %}Kitchen Display - Kwan's Restaurant{% endblock %}
{% block content %}
<div class="container-fluid mt-4">
  <h1>Kitchen Display System</h1>
  <p class="text-muted">Kitchen display interface coming soon...</p>
  <a href="{% url 'orders:dashboard' %}" class="btn btn-secondary">Back to Dashboard</a>
</div>
{% endblock %}""",

    "sales_dashboard.html": """{% extends "base.html" %}
{% block title %}Sales Analytics - Kwan's Restaurant{% endblock %}
{% block content %}
<div class="container-fluid mt-4">
  <h1>Sales Analytics</h1>
  <p class="text-muted">Sales analytics dashboard coming soon...</p>
  <a href="{% url 'orders:dashboard' %}" class="btn btn-secondary">Back to Dashboard</a>
</div>
{% endblock %}""",

    "customer_management.html": """{% extends "base.html" %}
{% block title %}Customer Management - Kwan's Restaurant{% endblock %}
{% block content %}
<div class="container-fluid mt-4">
  <h1>Customer Management</h1>
  <p class="text-muted">Customer management interface coming soon...</p>
  <a href="{% url 'orders:dashboard' %}" class="btn btn-secondary">Back to Dashboard</a>
</div>
{% endblock %}""",

    "menu_management.html": """{% extends "base.html" %}
{% block title %}Menu Management - Kwan's Restaurant{% endblock %}
{% block content %}
<div class="container-fluid mt-4">
  <h1>Menu Management</h1>
  <p class="text-muted">Menu management interface coming soon...</p>
  <a href="{% url 'orders:dashboard' %}" class="btn btn-secondary">Back to Dashboard</a>
</div>
{% endblock %}""",

    "feedback_management.html": """{% extends "base.html" %}
{% block title %}Feedback Management - Kwan's Restaurant{% endblock %}
{% block content %}
<div class="container mt-4">
  <h1>Feedback Management</h1>
  <p class="text-muted">Feedback management interface coming soon...</p>
  <a href="{% url 'orders:dashboard' %}" class="btn btn-secondary">Back to Dashboard</a>
</div>
{% endblock %}""",

    "employee_time_report.html": """{% extends "base.html" %}
{% block title %}Time Reports - Kwan's Restaurant{% endblock %}
{% block content %}
<div class="container mt-4">
  <h1>Employee Time Reports</h1>
  <p class="text-muted">Time reports interface coming soon...</p>
  <a href="{% url 'orders:reports' %}" class="btn btn-secondary">Back to Reports</a>
</div>
{% endblock %}""",

    "customer_analytics.html": """{% extends "base.html" %}
{% block title %}Customer Analytics - Kwan's Restaurant{% endblock %}
{% block content %}
<div class="container mt-4">
  <h1>Customer Analytics</h1>
  <p class="text-muted">Customer analytics coming soon...</p>
  <a href="{% url 'orders:reports' %}" class="btn btn-secondary">Back to Reports</a>
</div>
{% endblock %}""",

    "kitchen_performance.html": """{% extends "base.html" %}
{% block title %}Kitchen Performance - Kwan's Restaurant{% endblock %}
{% block content %}
<div class="container mt-4">
  <h1>Kitchen Performance</h1>
  <p class="text-muted">Kitchen performance metrics coming soon...</p>
  <a href="{% url 'orders:reports' %}" class="btn btn-secondary">Back to Reports</a>
</div>
{% endblock %}""",

    "menu_analytics.html": """{% extends "base.html" %}
{% block title %}Menu Analytics - Kwan's Restaurant{% endblock %}
{% block content %}
<div class="container mt-4">
  <h1>Menu Analytics</h1>
  <p class="text-muted">Menu analytics coming soon...</p>
  <a href="{% url 'orders:reports' %}" class="btn btn-secondary">Back to Reports</a>
</div>
{% endblock %}""",

    "sales_comparison.html": """{% extends "base.html" %}
{% block title %}Sales Comparison - Kwan's Restaurant{% endblock %}
{% block content %}
<div class="container mt-4">
  <h1>Sales Comparison</h1>
  <p class="text-muted">Sales comparison tool coming soon...</p>
  <a href="{% url 'orders:reports' %}" class="btn btn-secondary">Back to Reports</a>
</div>
{% endblock %}""",

    "daily_report.html": """{% extends "base.html" %}
{% block title %}Daily Report - Kwan's Restaurant{% endblock %}
{% block content %}
<div class="container mt-4">
  <h1>Daily Sales Report</h1>
  <p class="text-muted">Daily report generation coming soon...</p>
  <a href="{% url 'orders:reports' %}" class="btn btn-secondary">Back to Reports</a>
</div>
{% endblock %}""",
}

# Create the templates
created_count = 0
for filename, content in templates.items():
    filepath = os.path.join(BASE_DIR, filename)
    
    # Only create if it doesn't exist
    if not os.path.exists(filepath):
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Created: {filename}")
        created_count += 1
    else:
        print(f"Skipped (already exists): {filename}")

print(f"\nTotal templates created: {created_count}")
