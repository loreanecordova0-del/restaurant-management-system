from orders.models import Customer, Order
from django.db.models import Sum, Count

print("\n=== CUSTOMER DATA CHECK ===\n")

# Check customers
customers = Customer.objects.all()
print(f"Total Customers: {customers.count()}")

for customer in customers:
    print(f"\n{customer.first_name} {customer.last_name}")
    print(f"  Type: {customer.customer_type}")
    orders = Order.objects.filter(customer=customer)
    print(f"  Orders: {orders.count()}")
    total = orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    print(f"  Total Spent: ${total}")

print("\n=== SPENDING BY TYPE ===\n")

for customer_type in ['regular', 'pwd', 'senior']:
    customers_of_type = Customer.objects.filter(customer_type=customer_type)
    orders = Order.objects.filter(customer__in=customers_of_type)
    total_revenue = orders.aggregate(Sum('total_amount'))['total_amount__sum'] or 0
    order_count = orders.count()
    
    print(f"{customer_type.upper()}")
    print(f"  Customers: {customers_of_type.count()}")
    print(f"  Orders: {order_count}")
    print(f"  Revenue: ${total_revenue}")
    print()
